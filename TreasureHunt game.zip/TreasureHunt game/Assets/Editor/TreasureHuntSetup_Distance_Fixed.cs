using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

/// <summary>
/// TreasureHuntSetup: Editor script to automatically construct and wire all 4 scenes
/// (MainMenu, StageSelect, Information, GamePlay) and configure ProjectSettings.
/// </summary>
[InitializeOnLoad]
public class TreasureHuntSetup
{
    static TreasureHuntSetup()
    {
        EditorApplication.delayCall += EnsureTagsAndScenes;
    }

    [MenuItem("Treasure Hunt/Rebuild All Scenes & Assets")]
    public static void RebuildAll()
    {
        EnsureTags();
        BuildMainMenuScene();
        BuildStageSelectScene();
        BuildInformationScene();
        BuildGamePlayScene();
        UpdateBuildSettings();

        // Open MainMenu scene
        EditorSceneManager.OpenScene("Assets/Scenes/MainMenu.unity");
        Debug.Log(">>> [Treasure Hunt] All 4 Scenes built and wired successfully!");
    }

    private static void EnsureTagsAndScenes()
    {
        EnsureTags();
        FileInfo fi = new FileInfo("Assets/Scenes/GamePlay.unity");
        if (!fi.Exists || fi.Length < 3000)
        {
            RebuildAll();
        }
    }

    [MenuItem("Treasure Hunt/Play Main Menu Scene")]
    public static void PlayMainMenu()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/MainMenu.unity");
        EditorApplication.isPlaying = true;
    }

    [MenuItem("Treasure Hunt/Play GamePlay Scene Directly")]
    public static void PlayGamePlayDirectly()
    {
        EditorSceneManager.OpenScene("Assets/Scenes/GamePlay.unity");
        EditorApplication.isPlaying = true;
    }

    public static void EnsureTags()
    {
        Object tagManagerAsset = AssetDatabase.LoadMainAssetAtPath("ProjectSettings/TagManager.asset");
        if (tagManagerAsset == null)
        {
            Debug.LogWarning("[TreasureHuntSetup] TagManager.asset was not found. Skipping tag creation.");
            return;
        }

        SerializedObject tagManager = new SerializedObject(tagManagerAsset);
        SerializedProperty tagsProp = tagManager.FindProperty("tags");
        if (tagsProp == null)
        {
            Debug.LogWarning("[TreasureHuntSetup] TagManager does not expose a 'tags' property. Skipping tag creation.");
            return;
        }

        string[] requiredTags = new string[] { "Player", "Coin", "Gem", "Key", "Obstacle", "PowerUp" };
        foreach (string tag in requiredTags)
        {
            bool found = false;
            for (int i = 0; i < tagsProp.arraySize; i++)
            {
                SerializedProperty t = tagsProp.GetArrayElementAtIndex(i);
                if (t != null && t.stringValue == tag)
                {
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                tagsProp.InsertArrayElementAtIndex(tagsProp.arraySize);
                SerializedProperty n = tagsProp.GetArrayElementAtIndex(tagsProp.arraySize - 1);
                n.stringValue = tag;
            }
        }
        tagManager.ApplyModifiedProperties();
    }

    // ============================================================
    // SCENE 0: MAIN MENU
    // ============================================================
    public static void BuildMainMenuScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "MainMenu";

        // Atmosphere & Jungle Fog
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.015f;
        RenderSettings.fogColor = new Color(0.12f, 0.28f, 0.16f); // Deep emerald jungle mist

        // Camera
        GameObject camObj = new GameObject("Main Camera");
        camObj.tag = "MainCamera";
        Camera cam = camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.12f, 0.26f, 0.16f);
        camObj.transform.position = new Vector3(0, 2.8f, -7.0f);
        camObj.transform.rotation = Quaternion.Euler(14f, 0f, 0f);

        // Directional Light - Tropical Golden Sunbeams
        GameObject lightObj = new GameObject("Directional Light");
        Light light = lightObj.AddComponent<Light>();
        light.type = LightType.Directional;
        light.color = new Color(1.0f, 0.94f, 0.76f);
        light.intensity = 1.35f;
        lightObj.transform.rotation = Quaternion.Euler(48f, -32f, 0f);

        // World Builder & Explorer
        GameObject builderObj = new GameObject("JungleWorldBuilder");
        JungleWorldBuilder builder = builderObj.AddComponent<JungleWorldBuilder>();
        builder.CreateMaterialsIfNull();

        // 3D Explorer
        GameObject player = builder.BuildExplorerPlayer(new Vector3(0, 0, 0));
        PlayerMovement pm = player.GetComponent<PlayerMovement>();
        if (pm != null) pm.enabled = false;

        // Giant Mayan Temple Portal Arch in background
        builder.BuildTemplePortalArch(null, new Vector3(0, 0, 4.5f));

        // Lush Tropical Palm Trees flanking the temple
        builder.BuildPalmTree(null, new Vector3(-4.8f, 0, 1.2f));
        builder.BuildPalmTree(null, new Vector3(4.8f, 0, 1.5f));
        builder.BuildPalmTree(null, new Vector3(-6.2f, 0, 5.5f));
        builder.BuildPalmTree(null, new Vector3(6.2f, 0, 5.8f));

        // Ancient Carved Stone Pillars with Blazing Torches
        builder.BuildPillarWithTorch(null, new Vector3(-2.8f, 0, 0.5f));
        builder.BuildPillarWithTorch(null, new Vector3(2.8f, 0, 0.5f));

        // Open Treasure Chest overflowing with Gold & Gems
        builder.BuildTreasureChest(new Vector3(1.6f, 0, 0.8f));
        for (int i = 0; i < 6; i++)
        {
            builder.BuildGoldCoin(new Vector3(1.0f + i * 0.25f, 0.05f, 0.4f + Random.Range(0f, 0.4f)));
        }
        builder.BuildGem(new Vector3(2.3f, 0.15f, 0.6f));
        builder.BuildKey(new Vector3(-1.6f, 0.15f, 0.8f));

        // Side Waterfall Canyon Gorges
        builder.BuildWaterfallGorge(null, new Vector3(-12f, 0, 2f), true);
        builder.BuildWaterfallGorge(null, new Vector3(12f, 0, 2f), false);

        // Ancient Mossy Courtyard Ground Platform (24m x 24m)
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "TempleCourtyardGround";
        ground.transform.position = new Vector3(0, -0.25f, 2f);
        ground.transform.localScale = new Vector3(24f, 0.5f, 24f);
        ground.GetComponent<Renderer>().sharedMaterial = builder.stoneRoadMat;

        // UI Canvas & EventSystem
        CreateEventSystem();
        GameObject canvasObj = CreateCanvas("Canvas");

        // Title Text
        CreateText(canvasObj, "Title", "TREASURE HUNT\nJUNGLE RUINS", new Vector2(0, 180), new Vector2(600, 120), 46, Color.yellow, TextAnchor.MiddleCenter);

        // Subtitle
        CreateText(canvasObj, "Subtitle", " RUN  •  COLLECT  •  AVOID  •  SURVIVE ", new Vector2(0, 105), new Vector2(500, 40), 20, Color.white, TextAnchor.MiddleCenter);

        // Center "TAP TO START"
        CreateText(canvasObj, "TapToStart", "PRESS 'START GAME' TO EMBARK", new Vector2(0, -40), new Vector2(400, 40), 22, new Color(1f, 0.85f, 0.3f), TextAnchor.MiddleCenter);

        // Start Game Button
        GameObject startBtnObj = CreateButton(canvasObj, "StartGameBtn", "START", new Vector2(0, -150), new Vector2(260, 68));
        Button startBtn = startBtnObj.GetComponent<Button>();

        // Saved stats HUD (top left)
        GameObject coinHud = CreateText(canvasObj, "SavedCoins", "Coins: 0", new Vector2(-280, 200), new Vector2(180, 40), 22, Color.yellow, TextAnchor.MiddleLeft);
        GameObject gemHud = CreateText(canvasObj, "SavedGems", "Gems: 0", new Vector2(-280, 160), new Vector2(180, 40), 22, Color.cyan, TextAnchor.MiddleLeft);
        GameObject distHud = CreateText(canvasObj, "BestDist", "Best: 0 m", new Vector2(-280, 120), new Vector2(180, 40), 22, Color.white, TextAnchor.MiddleLeft);

        // Fade Out panel
        GameObject fadeOutObj = CreatePanel(canvasObj, "FadeOut", new Color(0, 0, 0, 1f));
        fadeOutObj.SetActive(false);

        // MainMenuControl script
        GameObject menuCtrlObj = new GameObject("MainMenuControl");
        MainMenuControl mmc = menuCtrlObj.AddComponent<MainMenuControl>();
        mmc.mainCam = camObj;
        mmc.fadeOut = fadeOutObj;
        mmc.startButton = startBtn;
        mmc.coinTotalText = coinHud.GetComponent<Text>();
        mmc.gemTotalText = gemHud.GetComponent<Text>();
        mmc.bestDistanceText = distHud.GetComponent<Text>();

        // Sound Manager
        CreateSoundManager();

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/MainMenu.unity");
    }

    // ============================================================
    // SCENE 1: STAGE SELECT
    // ============================================================
    public static void BuildStageSelectScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "StageSelect";

        GameObject camObj = new GameObject("Main Camera");
        camObj.tag = "MainCamera";
        Camera cam = camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.1f, 0.15f, 0.2f);
        camObj.transform.position = new Vector3(0, 1, -5f);

        GameObject lightObj = new GameObject("Directional Light");
        Light light = lightObj.AddComponent<Light>();
        light.type = LightType.Directional;
        lightObj.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        CreateEventSystem();
        GameObject canvasObj = CreateCanvas("Canvas");

        CreateText(canvasObj, "Header", "SELECT EXPEDITION STAGE", new Vector2(0, 210), new Vector2(600, 60), 38, Color.yellow, TextAnchor.MiddleCenter);

        GameObject titleObj = CreateText(canvasObj, "StageTitle", "1. JUNGLE RUINS (FEATURED)", new Vector2(0, 130), new Vector2(500, 50), 30, Color.green, TextAnchor.MiddleCenter);

        // Stage Description Card
        GameObject descObj = CreateText(canvasObj, "StageDesc",
            "Ancient Aztec & Mayan Temple Ruins deep in the emerald rainforest.\nAvoid wooden crates, spikes, rolling logs, boulders and ancient temple guards!\nCollect lost gold, sapphire gems, and golden keys.",
            new Vector2(0, 30), new Vector2(650, 120), 20, Color.white, TextAnchor.MiddleCenter);

        // World Cards Info
        CreateText(canvasObj, "OtherWorlds", "Other Themes: [ Desert Temple ] • [ Lost Cave ] • [ Pirate Cove ]", new Vector2(0, -60), new Vector2(600, 40), 18, Color.gray, TextAnchor.MiddleCenter);

        // PLAY Button
        GameObject playBtnObj = CreateButton(canvasObj, "PlayBtn", "PLAY JUNGLE RUINS", new Vector2(0, -150), new Vector2(280, 70));
        Button playBtn = playBtnObj.GetComponent<Button>();

        GameObject fadeOutObj = CreatePanel(canvasObj, "FadeOut", Color.black);
        fadeOutObj.SetActive(false);

        // StageControls script
        GameObject stageCtrlObj = new GameObject("StageControls");
        StageControls sc = stageCtrlObj.AddComponent<StageControls>();
        sc.stageTitleText = titleObj.GetComponent<Text>();
        sc.fadeOut = fadeOutObj;

        playBtn.onClick.AddListener(() => sc.PressPlay());

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/StageSelect.unity");
    }

    // ============================================================
    // SCENE 2: INFORMATION
    // ============================================================
    public static void BuildInformationScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "Information";

        GameObject camObj = new GameObject("Main Camera");
        camObj.tag = "MainCamera";
        Camera cam = camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.08f, 0.12f, 0.1f);
        camObj.transform.position = new Vector3(0, 1, -5f);

        CreateEventSystem();
        GameObject canvasObj = CreateCanvas("Canvas");

        CreateText(canvasObj, "Title", "EXPEDITION CONTROLS", new Vector2(0, 200), new Vector2(600, 60), 40, Color.yellow, TextAnchor.MiddleCenter);

        string instructions =
            "◄ A / LEFT ARROW (or Swipe Left) : Move Left Lane\n" +
            "► D / RIGHT ARROW (or Swipe Right) : Move Right Lane\n\n" +
            "▲ SPACE / W / UP (or Swipe Up) : JUMP over Crates, Spikes & Chasms\n\n" +
            "▼ S / DOWN (or Swipe Down) : SLIDE under Spiked Rolling Logs\n\n" +
            "★ COLLECT: Gold Coins (+1), Blue Gems (+1), Keys, & Chests\n" +
            "★ POWER-UPS: Shield (Absorbs hit), Magnet (Attracts coins), Speed Boost";

        CreateText(canvasObj, "Instructions", instructions, new Vector2(0, 15), new Vector2(750, 260), 20, Color.white, TextAnchor.MiddleLeft);

        GameObject loadingObj = CreateText(canvasObj, "LoadingText", "LOADING...", new Vector2(0, -180), new Vector2(300, 45), 26, Color.yellow, TextAnchor.MiddleCenter);

        CreateText(canvasObj, "SkipPrompt", "Tap or Press Space to start now", new Vector2(0, -220), new Vector2(400, 30), 16, Color.gray, TextAnchor.MiddleCenter);

        GameObject fadeOutObj = CreatePanel(canvasObj, "FadeOut", Color.black);
        fadeOutObj.SetActive(false);

        GameObject loaderObj = new GameObject("LoadToStage");
        LoadToStage lts = loaderObj.AddComponent<LoadToStage>();
        lts.fadeOut = fadeOutObj;
        lts.loadingText = loadingObj.GetComponent<Text>();
        lts.waitDuration = 2.5f;

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/Information.unity");
    }

    // ============================================================
    // SCENE 3: GAMEPLAY (ENDLESS RUNNER)
    // ============================================================
    public static void BuildGamePlayScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "GamePlay";

        // Atmosphere & Jungle Fog
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.012f;
        RenderSettings.fogColor = new Color(0.12f, 0.26f, 0.16f); // Deep emerald canopy fog

        // Main Camera
        GameObject camObj = new GameObject("Main Camera");
        camObj.tag = "MainCamera";
        Camera cam = camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.12f, 0.26f, 0.16f); // Jungle canopy mist
        camObj.transform.position = new Vector3(0, 3.8f, -5.5f);
        camObj.transform.rotation = Quaternion.Euler(15f, 0, 0);

        CameraFollow follow = camObj.AddComponent<CameraFollow>();

        // Directional Light - Warm Golden Sunlight
        GameObject lightObj = new GameObject("Directional Light");
        Light dirLight = lightObj.AddComponent<Light>();
        dirLight.type = LightType.Directional;
        dirLight.color = new Color(1.0f, 0.94f, 0.76f);
        dirLight.intensity = 1.35f;
        lightObj.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        // Sound Manager
        CreateSoundManager();

        // World Builder
        GameObject builderObj = new GameObject("JungleWorldBuilder");
        JungleWorldBuilder builder = builderObj.AddComponent<JungleWorldBuilder>();
        builder.CreateMaterialsIfNull();

        // Build Explorer Player
        GameObject player = builder.BuildExplorerPlayer(new Vector3(0, 0, 0));
        follow.target = player.transform;

        // Start Runway (Segment 0) with Temple Portal Arch
        GameObject startSeg = builder.BuildSegmentBase("StartSegment", 50f);
        startSeg.transform.position = Vector3.zero;
        builder.BuildTemplePortalArch(startSeg.transform, new Vector3(0, 0, 18f));

        // Create Segment Templates
        GameObject segA = builder.CreateSegmentA(); segA.SetActive(false);
        GameObject segB = builder.CreateSegmentB(); segB.SetActive(false);
        GameObject segC = builder.CreateSegmentC(); segC.SetActive(false);
        GameObject segD = builder.CreateSegmentD(); segD.SetActive(false);
        GameObject segE = builder.CreateSegmentE(); segE.SetActive(false);

        // Segment Generator
        GameObject segGenObj = new GameObject("SegmentGenerator");
        SegmentGenerator segGen = segGenObj.AddComponent<SegmentGenerator>();
        segGen.playerTransform = player.transform;
        segGen.zPos = 50;
        segGen.segment = new GameObject[] { segA, segB, segC, segD, segE };

        // Create UI Canvas
        CreateEventSystem();
        GameObject canvasObj = CreateCanvas("Canvas");

        // HUD Panel
        GameObject hudPanel = new GameObject("HUDPanel");
        hudPanel.transform.SetParent(canvasObj.transform, false);
        RectTransform hudRect = hudPanel.AddComponent<RectTransform>();
        hudRect.anchorMin = Vector2.zero;
        hudRect.anchorMax = Vector2.one;
        hudRect.offsetMin = Vector2.zero;
        hudRect.offsetMax = Vector2.zero;

        // Top HUD Displays
        // Top HUD Displays
        GameObject coinTextObj = CreateText(hudPanel, "CoinDisplay", "COINS: 0",
        new Vector2(-295, 200), new Vector2(160, 50), 24, Color.yellow, TextAnchor.MiddleLeft);

        GameObject gemTextObj = CreateText(hudPanel, "GemDisplay", "GEMS: 0",
        new Vector2(-85, 200), new Vector2(170, 50), 24, Color.cyan, TextAnchor.MiddleLeft);

        GameObject keyTextObj = CreateText(hudPanel, "KeyDisplay", "KEYS: 0",
        new Vector2(115, 200), new Vector2(180, 50), 24, Color.yellow, TextAnchor.MiddleLeft);

        GameObject distTextObj = CreateText(hudPanel, "DistanceDisplay", "DISTANCE: 0 m",
        new Vector2(275, 200), new Vector2(190, 50), 23, Color.cyan, TextAnchor.MiddleCenter);

        // Pause Button
        GameObject pauseBtnObj = CreateButton(hudPanel, "PauseBtn", "⏸",
        new Vector2(400, 200), new Vector2(50, 50));
        Button pauseBtn = pauseBtnObj.GetComponent<Button>();

        // Power-up Active Indicators
        GameObject shieldInd = CreateText(hudPanel, "ShieldActive", "🛡️ SHIELD ACTIVE", new Vector2(0, 150), new Vector2(250, 35), 20, Color.cyan, TextAnchor.MiddleCenter);
        shieldInd.SetActive(false);

        GameObject magnetInd = CreateText(hudPanel, "MagnetActive", "🧲 MAGNET ACTIVE", new Vector2(0, 120), new Vector2(250, 35), 20, Color.red, TextAnchor.MiddleCenter);
        magnetInd.SetActive(false);

        // MasterLevelInfo HUD controller
        GameObject levelInfoObj = new GameObject("MasterLevelInfo");
        MasterLevelInfo mli = levelInfoObj.AddComponent<MasterLevelInfo>();
        mli.coinDisplay = coinTextObj;
        mli.gemDisplay = gemTextObj;
        mli.keyDisplay = keyTextObj;
        mli.runDisplay = distTextObj;

        // SaveLoad Manager
        levelInfoObj.AddComponent<SaveLoad>();

        // Pause Panel
        GameObject pausePanel = CreatePanel(canvasObj, "PausePanel", new Color(0, 0, 0, 0.85f));
        CreateText(pausePanel, "PauseTitle", "GAME PAUSED", new Vector2(0, 100), new Vector2(400, 60), 38, Color.yellow, TextAnchor.MiddleCenter);
        GameObject resumeBtnObj = CreateButton(pausePanel, "ResumeBtn", "RESUME", new Vector2(0, 20), new Vector2(220, 55));
        GameObject restartBtnObj = CreateButton(pausePanel, "RestartBtn", "RESTART", new Vector2(0, -50), new Vector2(220, 55));
        GameObject menuBtnObj = CreateButton(pausePanel, "MenuBtn", "MAIN MENU", new Vector2(0, -120), new Vector2(220, 55));
        pausePanel.SetActive(false);

        // Game Over Panel
        GameObject gameOverPanel = CreatePanel(canvasObj, "GameOverPanel", new Color(0, 0, 0, 0.92f));
        CreateText(gameOverPanel, "GameOverTitle", "EXPEDITION FAILED!", new Vector2(0, 150), new Vector2(500, 60), 42, Color.red, TextAnchor.MiddleCenter);

        GameObject scoreTextObj = CreateText(gameOverPanel, "FinalScore", "SCORE: 0 m\nCOINS: 0", new Vector2(0, 70), new Vector2(400, 80), 26, Color.white, TextAnchor.MiddleCenter);
        GameObject bestTextObj = CreateText(gameOverPanel, "BestScore", "BEST: 0 m", new Vector2(0, 10), new Vector2(400, 40), 22, Color.yellow, TextAnchor.MiddleCenter);

        GameObject reviveBtnObj = CreateButton(gameOverPanel, "ReviveBtn", "REVIVE (20 GEMS)", new Vector2(0, -60), new Vector2(260, 60));
        GameObject retryBtnObj = CreateButton(gameOverPanel, "RetryBtn", "RETRY RUN", new Vector2(-110, -140), new Vector2(180, 55));
        GameObject homeBtnObj = CreateButton(gameOverPanel, "HomeBtn", "MAIN MENU", new Vector2(110, -140), new Vector2(180, 55));
        gameOverPanel.SetActive(false);

        // GameUIManager
        GameObject uiMgrObj = new GameObject("GameUIManager");
        GameUIManager uiMgr = uiMgrObj.AddComponent<GameUIManager>();
        uiMgr.hudPanel = hudPanel;
        uiMgr.pausePanel = pausePanel;
        uiMgr.gameOverPanel = gameOverPanel;
        uiMgr.finalScoreText = scoreTextObj.GetComponent<Text>();
        uiMgr.bestScoreText = bestTextObj.GetComponent<Text>();
        uiMgr.reviveCostText = reviveBtnObj.GetComponentInChildren<Text>();
        uiMgr.reviveButton = reviveBtnObj.GetComponent<Button>();
        uiMgr.retryButton = retryBtnObj.GetComponent<Button>();
        uiMgr.homeButton = homeBtnObj.GetComponent<Button>();
        uiMgr.shieldIndicator = shieldInd;
        uiMgr.magnetIndicator = magnetInd;

        uiMgr.WireAllPanelButtons();

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/GamePlay.unity");
    }

    private static void UpdateBuildSettings()
    {
        EditorBuildSettingsScene[] scenes = new EditorBuildSettingsScene[]
        {
            new EditorBuildSettingsScene("Assets/Scenes/MainMenu.unity", true),
            new EditorBuildSettingsScene("Assets/Scenes/StageSelect.unity", true),
            new EditorBuildSettingsScene("Assets/Scenes/Information.unity", true),
            new EditorBuildSettingsScene("Assets/Scenes/GamePlay.unity", true)
        };
        EditorBuildSettings.scenes = scenes;
    }

    // UI Creation Utilities
    private static GameObject CreateCanvas(string name)
    {
        GameObject canvasObj = new GameObject(name);
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(960, 540);
        canvasObj.AddComponent<GraphicRaycaster>();
        return canvasObj;
    }

    private static void CreateEventSystem()
    {
        if (Object.FindAnyObjectByType<EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }
    }

    private static GameObject CreateText(GameObject parent, string name, string text, Vector2 pos, Vector2 size, int fontSize, Color color, TextAnchor alignment)
    {
        GameObject obj = new GameObject(name);
        obj.transform.SetParent(parent.transform, false);
        Text t = obj.AddComponent<Text>();
        t.text = text;
        t.fontSize = fontSize;
        t.color = color;
        t.alignment = alignment;
        t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (t.font == null) t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");

        RectTransform rt = obj.GetComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return obj;
    }

    private static GameObject CreateButton(GameObject parent, string name, string label, Vector2 pos, Vector2 size)
    {
        GameObject btnObj = new GameObject(name);
        btnObj.transform.SetParent(parent.transform, false);

        Image img = btnObj.AddComponent<Image>();
        img.color = new Color(0.9f, 0.72f, 0.15f);

        Button btn = btnObj.AddComponent<Button>();
        ColorBlock cb = btn.colors;
        cb.highlightedColor = new Color(1.0f, 0.85f, 0.35f);
        cb.pressedColor = new Color(0.75f, 0.55f, 0.05f);
        btn.colors = cb;

        RectTransform rt = btnObj.GetComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;

        CreateText(btnObj, "Label", label, Vector2.zero, size, 22, Color.black, TextAnchor.MiddleCenter);

        return btnObj;
    }

    private static GameObject CreatePanel(GameObject parent, string name, Color color)
    {
        GameObject panel = new GameObject(name);
        panel.transform.SetParent(parent.transform, false);
        Image img = panel.AddComponent<Image>();
        img.color = color;
        RectTransform rt = panel.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        return panel;
    }

    private static void CreateSoundManager()
    {
        if (Object.FindAnyObjectByType<SoundManager>() == null)
        {
            GameObject smObj = new GameObject("SoundManager");
            SoundManager sm = smObj.AddComponent<SoundManager>();

            // Auto-load audio clips if available in Assets/Audio
            sm.coinClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/coin_pickup.wav");
            sm.gemClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/gem_pickup.wav");
            sm.keyClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/key_pickup.wav");
            sm.collisionClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/collision.wav");
            sm.jumpClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/jump.wav");
            sm.slideClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/slide.wav");
            sm.buttonClickClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/button_click.wav");
            sm.powerUpClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/powerup.wav");
            sm.bgmMusicClip = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Audio/jungle_bgm.wav");
        }
    }
}
