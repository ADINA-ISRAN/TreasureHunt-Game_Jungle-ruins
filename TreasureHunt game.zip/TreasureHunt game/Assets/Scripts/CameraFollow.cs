using UnityEngine;

/// <summary>
/// CameraFollow: Smooth 3rd-person chase camera tailored for endless runners.
/// Follows the player along the Z running axis with customizable offset,
/// smooth X-lane dampening, and camera collision shake effects.
/// </summary>
public class CameraFollow : MonoBehaviour
{
    [Header("Target & Offset")]
    public Transform target;
    public Vector3 offset = new Vector3(0f, 3.8f, -5.5f);
    public float lookAhead = 12f;

    [Header("Smoothing")]
    public float smoothSpeedX = 6f;
    public float smoothSpeedY = 4f;

    [Header("Shake")]
    private float shakeDuration = 0f;
    private float shakeMagnitude = 0.3f;

    void Start()
    {
        if (target == null)
        {
            GameObject p = GameObject.FindWithTag("Player");
            if (p != null) target = p.transform;
        }
    }

    void LateUpdate()
    {
        if (target == null) return;

        // Desired position
        float currentX = Mathf.Lerp(transform.position.x, target.position.x + offset.x, Time.deltaTime * smoothSpeedX);
        float currentY = Mathf.Lerp(transform.position.y, target.position.y + offset.y, Time.deltaTime * smoothSpeedY);
        float currentZ = target.position.z + offset.z;

        Vector3 desiredPosition = new Vector3(currentX, currentY, currentZ);

        // Apply shake if active
        if (shakeDuration > 0)
        {
            desiredPosition += Random.insideUnitSphere * shakeMagnitude;
            shakeDuration -= Time.deltaTime;
        }

        transform.position = desiredPosition;

        // Look slightly ahead of player on the track
        Vector3 lookTarget = new Vector3(target.position.x * 0.5f, target.position.y + 1.2f, target.position.z + lookAhead);
        transform.rotation = Quaternion.LookRotation(lookTarget - transform.position);
    }

    public void TriggerShake(float duration = 0.4f, float magnitude = 0.35f)
    {
        shakeDuration = duration;
        shakeMagnitude = magnitude;
    }
}
