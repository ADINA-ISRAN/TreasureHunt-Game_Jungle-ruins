using System.Collections;
using UnityEngine;

/// <summary>
/// CollectCoin: Handles coin pickup - plays sound, adds to coinCount,
/// shrinks and floats upward, then disables itself.
/// </summary>
public class CollectCoin : MonoBehaviour
{
    [SerializeField] private bool collectedCoin = false;
    [SerializeField] public AudioSource coinDing;

    void Update()
    {
        if (!collectedCoin)
        {
            transform.Rotate(0, 2.5f, 0, Space.World);
        }
        else
        {
            // Upward motion when collected
            transform.Translate(Vector3.up * Time.deltaTime * 6f, Space.World);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (collectedCoin) return;
        if (!other.CompareTag("Player") && other.GetComponent<PlayerMovement>() == null) return;

        collectedCoin = true;
        MasterLevelInfo.coinCount += (int)(1 * MasterLevelInfo.scoreMultiplier);

        if (coinDing != null)
        {
            coinDing.Play();
        }
        else if (SoundManager.Instance != null)
        {
            SoundManager.Instance.PlayCoin();
        }

        Animator anim = GetComponent<Animator>();
        if (anim != null && anim.HasState(0, Animator.StringToHash("Shrink")))
        {
            anim.Play("Shrink");
        }
        else
        {
            StartCoroutine(ShrinkScale());
        }

        StartCoroutine(DeleteCoin());
    }

    private IEnumerator ShrinkScale()
    {
        Vector3 initialScale = transform.localScale;
        float elapsed = 0f;
        while (elapsed < 0.4f)
        {
            elapsed += Time.deltaTime;
            transform.localScale = Vector3.Lerp(initialScale, Vector3.zero, elapsed / 0.4f);
            yield return null;
        }
    }

    private IEnumerator DeleteCoin()
    {
        yield return new WaitForSeconds(0.45f);
        gameObject.SetActive(false);
    }
}
