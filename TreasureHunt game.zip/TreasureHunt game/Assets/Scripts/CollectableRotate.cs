using UnityEngine;

/// <summary>
/// CollectableRotate: Continuously rotates coins, gems, and keys around the Y-axis
/// as described in the game presentation, with optional floating bob motion.
/// </summary>
public class CollectableRotate : MonoBehaviour
{
    [SerializeField] public float rotateSpeed = 2f;
    [SerializeField] public bool bobbing = true;
    [SerializeField] public float bobHeight = 0.15f;
    [SerializeField] public float bobSpeed = 3f;

    private float startY;

    void Start()
    {
        startY = transform.position.y;
    }

    void Update()
    {
        // 1. World Y-axis spin
        transform.Rotate(0, rotateSpeed, 0, Space.World);

        // 2. Gentle vertical bobbing
        if (bobbing)
        {
            float newY = startY + Mathf.Sin(Time.time * bobSpeed) * bobHeight;
            transform.position = new Vector3(transform.position.x, newY, transform.position.z);
        }
    }
}
