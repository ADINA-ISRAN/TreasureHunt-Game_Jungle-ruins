using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// CollisionDetect: Attached to obstacles (Crates, Spikes, Boulders, Logs, Guards).
/// Checks player collision, verifies shield protection, plays impact sound & stumble animation,
/// saves progress, and triggers Game Over / Revive menu.
/// </summary>
public class CollisionDetect : MonoBehaviour
{
    [Header("References")]
    [SerializeField] public GameObject thePlayer;
    [SerializeField] public GameObject playerAnim;
    [SerializeField] public GameObject mainCam;
    [SerializeField] public GameObject fadeOut;
    [SerializeField] public AudioSource collisionFX;
    [SerializeField] public GameUIManager gameUI;

    [Header("Settings")]
    [SerializeField] private bool hasTriggered = false;

    void Start()
    {
        if (thePlayer == null)
        {
            thePlayer = GameObject.FindWithTag("Player");
        }
        if (gameUI == null)
        {
            gameUI = Object.FindAnyObjectByType<GameUIManager>();
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (hasTriggered) return;

        PlayerMovement player = other.GetComponent<PlayerMovement>();
        if (player == null) player = other.GetComponentInParent<PlayerMovement>();
        if (player == null && other.CompareTag("Player"))
        {
            if (thePlayer != null) player = thePlayer.GetComponent<PlayerMovement>();
        }

        if (player != null && player.isAlive)
        {
            // 1. Check Shield Power-up Protection
            if (player.hasShield)
            {
                player.hasShield = false;
                hasTriggered = true;
                if (collisionFX != null) collisionFX.Play();
                else if (SoundManager.Instance != null) SoundManager.Instance.PlayCollision();

                // Knock back/disable this obstacle
                gameObject.SetActive(false);
                return;
            }

            hasTriggered = true;
            SaveLoad.saveData = true;
            SaveLoad.ExecuteSave();

            StartCoroutine(CollisionEnd(player));
        }
    }

    IEnumerator CollisionEnd(PlayerMovement player)
    {
        player.isAlive = false;

        if (collisionFX != null)
        {
            collisionFX.Play();
        }
        else if (SoundManager.Instance != null)
        {
            SoundManager.Instance.PlayCollision();
        }

        player.enabled = false;

        if (playerAnim != null)
        {
            Animator anim = playerAnim.GetComponent<Animator>();
            if (anim != null && anim.HasState(0, Animator.StringToHash("Stumble Backwards")))
            {
                anim.Play("Stumble Backwards");
            }
        }

        if (mainCam != null)
        {
            Animator camAnim = mainCam.GetComponent<Animator>();
            if (camAnim != null && camAnim.HasState(0, Animator.StringToHash("CollisionCam")))
            {
                camAnim.Play("CollisionCam");
            }
        }

        yield return new WaitForSeconds(1.2f);

        // Show Game Over UI if available
        if (gameUI != null)
        {
            gameUI.ShowGameOverScreen();
        }
        else
        {
            if (fadeOut != null) fadeOut.SetActive(true);
            yield return new WaitForSeconds(2f);
            SceneManager.LoadScene(0);
        }
    }
}
