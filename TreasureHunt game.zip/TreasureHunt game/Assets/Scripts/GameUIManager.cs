using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// GameUIManager: Manages in-game HUD, Pause menu, and the Game Over screen
/// with bulletproof button binding for Revive (20 Gems), Retry, and Home.
/// </summary>
public class GameUIManager : MonoBehaviour
{
    [Header("Panels")]
    public GameObject hudPanel;
    public GameObject pausePanel;
    public GameObject gameOverPanel;

    [Header("Game Over Displays")]
    public Text finalScoreText;
    public Text bestScoreText;
    public Text reviveCostText;
    public Button reviveButton;
    public Button retryButton;
    public Button homeButton;

    [Header("Status & Power-up HUD")]
    public GameObject shieldIndicator;
    public GameObject magnetIndicator;

    private PlayerMovement player;

    void Awake()
    {
        Time.timeScale = 1f;
    }

    void Start()
    {
        player = Object.FindAnyObjectByType<PlayerMovement>();

        // Wire all buttons before changing panel active states
        WireAllPanelButtons();

        if (pausePanel != null) pausePanel.SetActive(false);
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        if (hudPanel != null) hudPanel.SetActive(true);
        Time.timeScale = 1f;
    }

    void Update()
    {
        // Keyboard Shortcuts on Game Over Screen
        if (gameOverPanel != null && gameOverPanel.activeSelf)
        {
            if (Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
            {
                OnPressRetry();
                return;
            }
            if (Input.GetKeyDown(KeyCode.H) || Input.GetKeyDown(KeyCode.Escape))
            {
                OnPressHome();
                return;
            }
        }

        // Toggle pause on Escape or P during gameplay
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            if (pausePanel != null && (gameOverPanel == null || !gameOverPanel.activeSelf))
            {
                if (pausePanel.activeSelf) ResumeGame();
                else PauseGame();
            }
        }

        // Power-up indicators
        if (player != null)
        {
            if (shieldIndicator != null) shieldIndicator.SetActive(player.hasShield);
            if (magnetIndicator != null) magnetIndicator.SetActive(player.hasMagnet);
        }
    }

    public void WireAllPanelButtons()
    {
        // 1. HUD Buttons
        WireButtonNamed("PauseBtn", PauseGame);

        // 2. Pause Panel Buttons
        WireButtonNamed("ResumeBtn", ResumeGame);
        WireButtonNamed("RestartBtn", OnPressRetry);
        WireButtonNamed("MenuBtn", OnPressHome);

        // 3. Game Over Panel Buttons
        WireButtonNamed("ReviveBtn", OnPressRevive);
        WireButtonNamed("RetryBtn", OnPressRetry);
        WireButtonNamed("HomeBtn", OnPressHome);
    }

    private void WireButtonNamed(string buttonName, UnityEngine.Events.UnityAction action)
    {
        // Search across all buttons in all canvases, including inactive
        Button[] allButtons = Resources.FindObjectsOfTypeAll<Button>();
        foreach (Button b in allButtons)
        {
            if (b != null && b.gameObject.name == buttonName)
            {
                b.onClick.RemoveAllListeners();
                b.onClick.AddListener(action);
            }
        }
    }

    public void PauseGame()
    {
        if (pausePanel != null) pausePanel.SetActive(true);
        Time.timeScale = 0f;
        if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();
    }

    public void ResumeGame()
    {
        if (pausePanel != null) pausePanel.SetActive(false);
        Time.timeScale = 1f;
        if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();
    }

    public void ShowGameOverScreen()
    {
        Time.timeScale = 1f; // Ensure timeScale is normal
        if (hudPanel != null) hudPanel.SetActive(false);
        if (pausePanel != null) pausePanel.SetActive(false);
        if (gameOverPanel != null) gameOverPanel.SetActive(true);

        // Ensure buttons are active and wired
        WireAllPanelButtons();

        int currentScore = MasterLevelInfo.distanceRun;
        int bestScore = Mathf.Max(SaveLoad.loadedDistance, currentScore);

        if (finalScoreText != null)
        {
            finalScoreText.text = $"SCORE: {currentScore} m\nCOINS: {MasterLevelInfo.coinCount}";
        }
        if (bestScoreText != null)
        {
            bestScoreText.text = $"BEST: {bestScore} m";
        }

        int totalGems = SaveLoad.loadedGems + MasterLevelInfo.gemCount;
        if (reviveCostText != null)
        {
            reviveCostText.text = $"REVIVE (20 GEMS)\nHave: {totalGems}";
        }
    }

    public void OnPressRevive()
    {
        int totalGems = SaveLoad.loadedGems + MasterLevelInfo.gemCount;
        if (totalGems >= 20)
        {
            SaveLoad.TryDeductGems(20);
        }

        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        if (hudPanel != null) hudPanel.SetActive(true);

        if (player != null)
        {
            player.enabled = true;
            player.RevivePlayer();
        }

        if (SoundManager.Instance != null) SoundManager.Instance.PlayPowerUp();
    }

    public void OnPressRetry()
    {
        Time.timeScale = 1f;
        if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();

        // Safely reload the GamePlay scene
        string currentScene = SceneManager.GetActiveScene().name;
        if (string.IsNullOrEmpty(currentScene) || currentScene.ToLower().Contains("untitled"))
        {
            currentScene = "GamePlay";
        }
        SceneManager.LoadScene(currentScene);
    }

    public void OnPressHome()
    {
        Time.timeScale = 1f;
        if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();

        if (Application.CanStreamedLevelBeLoaded("MainMenu"))
        {
            SceneManager.LoadScene("MainMenu");
        }
        else
        {
            SceneManager.LoadScene(0);
        }
    }
}
