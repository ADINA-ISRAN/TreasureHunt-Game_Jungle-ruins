using System.Collections;
using UnityEngine;

/// <summary>
/// GemCollect: Handles rare blue gem collection, playing gemFX chime,
/// incrementing MasterLevelInfo.gemCount, and triggering shrink animation.
/// </summary>
public class GemCollect : MonoBehaviour
{
    [SerializeField] private bool collectedGem = false;
    [SerializeField] public AudioSource gemFx;

    void Update()
    {
        if (!collectedGem)
        {
            transform.Rotate(0, 2.5f, 0, Space.World);
        }
        else
        {
            transform.Translate(Vector3.up * Time.deltaTime * 6f, Space.World);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (collectedGem) return;
        if (!other.CompareTag("Player") && other.GetComponent<PlayerMovement>() == null) return;

        collectedGem = true;
        MasterLevelInfo.gemCount += 1;

        if (gemFx != null)
        {
            gemFx.Play();
        }
        else if (SoundManager.Instance != null)
        {
            SoundManager.Instance.PlayGem();
        }

        Animator anim = GetComponent<Animator>();
        if (anim != null && anim.HasState(0, Animator.StringToHash("Shrink")))
        {
            anim.Play("Shrink");
        }
        else
        {
            StartCoroutine(ShrinkScale());
        }

        StartCoroutine(DeleteGem());
    }

    private IEnumerator ShrinkScale()
    {
        Vector3 initialScale = transform.localScale;
        float elapsed = 0f;
        while (elapsed < 0.45f)
        {
            elapsed += Time.deltaTime;
            transform.localScale = Vector3.Lerp(initialScale, Vector3.zero, elapsed / 0.45f);
            yield return null;
        }
    }

    private IEnumerator DeleteGem()
    {
        yield return new WaitForSeconds(0.5f);
        gameObject.SetActive(false);
    }
}
