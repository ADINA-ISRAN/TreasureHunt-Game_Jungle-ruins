using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

/// <summary>
/// JungleWorldBuilder: Comprehensive 3D procedural generator for the Jungle Ruins theme.
/// Generates authentic ancient Mayan/Aztec temple ruins, lush tropical palm trees,
/// giant carved stone idol heads, hanging vines, cascading waterfalls, torches, and hazards.
/// </summary>
public class JungleWorldBuilder : MonoBehaviour
{
    public static JungleWorldBuilder Instance { get; private set; }

    [Header("Theme Materials")]
    public Material stoneRoadMat;
    public Material mossyStoneMat;
    public Material ruinPillarMat;
    public Material goldMat;
    public Material gemBlueMat;
    public Material woodMat;
    public Material ironSpikeMat;
    public Material guardClothMat;
    public Material explorerMat;
    public Material torchFireMat;
    public Material shieldMat;
    public Material palmLeafMat;
    public Material palmBarkMat;
    public Material waterMat;
    public Material vineMat;
    public Material jungleGroundMat;
    public Material darkLeafMat;
    public Material fernMat;
    public Material jungleRockMat;
    public Material flowerMat;

    void Awake()
    {
        Instance = this;
        CreateMaterialsIfNull();
    }

    public void CreateMaterialsIfNull()
    {
        Shader standardShader = Shader.Find("Standard");
        if (standardShader == null) standardShader = Shader.Find("Universal Render Pipeline/Lit");
        if (standardShader == null) standardShader = Shader.Find("Diffuse");

        // Helper to load texture from disk
        Texture2D stoneTex = LoadTextureFile("Assets/Textures/stone_moss_bricks.png");
        Texture2D leafTex = LoadTextureFile("Assets/Textures/jungle_palm_leaves.png");
        Texture2D woodTex = LoadTextureFile("Assets/Textures/ancient_wood_crate.png");
        Texture2D goldTex = LoadTextureFile("Assets/Textures/ancient_gold_chest.png");
        Texture2D waterTex = LoadTextureFile("Assets/Textures/waterfall_stream.png");

        if (stoneRoadMat == null)
        {
            stoneRoadMat = new Material(standardShader);
            stoneRoadMat.name = "StoneRoadMat";
            stoneRoadMat.color = new Color(0.65f, 0.62f, 0.52f);
            if (stoneTex != null)
            {
                stoneRoadMat.mainTexture = stoneTex;
                stoneRoadMat.mainTextureScale = new Vector2(4, 25);
            }
        }
        if (mossyStoneMat == null)
        {
            mossyStoneMat = new Material(standardShader);
            mossyStoneMat.name = "MossyStoneMat";
            mossyStoneMat.color = new Color(0.42f, 0.55f, 0.35f);
            if (stoneTex != null)
            {
                mossyStoneMat.mainTexture = stoneTex;
                mossyStoneMat.mainTextureScale = new Vector2(2, 6);
            }
        }
        if (ruinPillarMat == null)
        {
            ruinPillarMat = new Material(standardShader);
            ruinPillarMat.name = "RuinPillarMat";
            ruinPillarMat.color = new Color(0.50f, 0.52f, 0.44f);
            if (stoneTex != null)
            {
                ruinPillarMat.mainTexture = stoneTex;
                ruinPillarMat.mainTextureScale = new Vector2(1, 4);
            }
        }
        if (palmLeafMat == null)
        {
            palmLeafMat = new Material(standardShader);
            palmLeafMat.name = "PalmLeafMat";
            palmLeafMat.color = new Color(0.25f, 0.68f, 0.22f);
            if (leafTex != null)
            {
                palmLeafMat.mainTexture = leafTex;
                palmLeafMat.mainTextureScale = new Vector2(1, 2);
            }
        }
        if (palmBarkMat == null)
        {
            palmBarkMat = new Material(standardShader);
            palmBarkMat.name = "PalmBarkMat";
            palmBarkMat.color = new Color(0.48f, 0.32f, 0.18f);
            if (woodTex != null) palmBarkMat.mainTexture = woodTex;
        }
        if (waterMat == null)
        {
            waterMat = new Material(standardShader);
            waterMat.name = "WaterMat";
            waterMat.color = new Color(0.15f, 0.75f, 0.85f, 0.85f);
            if (waterTex != null)
            {
                waterMat.mainTexture = waterTex;
                waterMat.mainTextureScale = new Vector2(4, 20);
            }
        }
        if (vineMat == null)
        {
            vineMat = new Material(standardShader);
            vineMat.name = "VineMat";
            vineMat.color = new Color(0.18f, 0.45f, 0.15f);
            if (leafTex != null) vineMat.mainTexture = leafTex;
        }
        if (goldMat == null)
        {
            goldMat = new Material(standardShader);
            goldMat.name = "GoldMat";
            goldMat.color = new Color(1.0f, 0.84f, 0.15f);
            if (goldTex != null) goldMat.mainTexture = goldTex;
        }
        if (gemBlueMat == null)
        {
            gemBlueMat = new Material(standardShader);
            gemBlueMat.name = "GemBlueMat";
            gemBlueMat.color = new Color(0.08f, 0.72f, 1.0f);
        }
        if (woodMat == null)
        {
            woodMat = new Material(standardShader);
            woodMat.name = "WoodMat";
            woodMat.color = new Color(0.65f, 0.42f, 0.22f);
            if (woodTex != null) woodMat.mainTexture = woodTex;
        }
        if (ironSpikeMat == null)
        {
            ironSpikeMat = new Material(standardShader);
            ironSpikeMat.name = "IronSpikeMat";
            ironSpikeMat.color = new Color(0.28f, 0.30f, 0.35f);
        }
        if (guardClothMat == null)
        {
            guardClothMat = new Material(standardShader);
            guardClothMat.name = "GuardClothMat";
            guardClothMat.color = new Color(0.88f, 0.22f, 0.15f);
        }
        if (explorerMat == null)
        {
            explorerMat = new Material(standardShader);
            explorerMat.name = "ExplorerMat";
            explorerMat.color = new Color(0.82f, 0.72f, 0.52f);
        }
        if (torchFireMat == null)
        {
            torchFireMat = new Material(standardShader);
            torchFireMat.name = "TorchFireMat";
            torchFireMat.color = new Color(1.0f, 0.65f, 0.05f);
        }
        if (shieldMat == null)
        {
            shieldMat = new Material(standardShader);
            shieldMat.name = "ShieldBubbleMat";
            shieldMat.color = new Color(0.2f, 0.75f, 1.0f, 0.45f);
        }
        if (jungleGroundMat == null)
        {
            jungleGroundMat = new Material(standardShader);
            jungleGroundMat.name = "JungleGroundMat";
            jungleGroundMat.color = new Color(0.16f, 0.30f, 0.12f);
        }
        if (darkLeafMat == null)
        {
            darkLeafMat = new Material(standardShader);
            darkLeafMat.name = "DarkJungleLeafMat";
            darkLeafMat.color = new Color(0.055f, 0.22f, 0.075f);
        }
        if (fernMat == null)
        {
            fernMat = new Material(standardShader);
            fernMat.name = "FernMat";
            fernMat.color = new Color(0.20f, 0.48f, 0.12f);
        }
        if (jungleRockMat == null)
        {
            jungleRockMat = new Material(standardShader);
            jungleRockMat.name = "JungleRockMat";
            jungleRockMat.color = new Color(0.25f, 0.29f, 0.20f);
        }
        if (flowerMat == null)
        {
            flowerMat = new Material(standardShader);
            flowerMat.name = "JungleFlowerMat";
            flowerMat.color = new Color(1.0f, 0.66f, 0.12f);
        }
    }

    private Texture2D LoadTextureFile(string relativePath)
    {
#if UNITY_EDITOR
        Texture2D assetTex = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>(relativePath);
        if (assetTex != null) return assetTex;
#endif
        string fullPath = Path.Combine(Application.dataPath, relativePath.Replace("Assets/", ""));
        if (File.Exists(fullPath))
        {
            try
            {
                byte[] bytes = File.ReadAllBytes(fullPath);
                Texture2D tex = new Texture2D(256, 256, TextureFormat.RGBA32, true);
                tex.wrapMode = TextureWrapMode.Repeat;
                var imgConvType = System.Type.GetType("UnityEngine.ImageConversion, UnityEngine.ImageConversionModule") 
                                  ?? System.Type.GetType("UnityEngine.ImageConversion, UnityEngine");
                if (imgConvType != null)
                {
                    var loadMethod = imgConvType.GetMethod("LoadImage", new System.Type[] { typeof(Texture2D), typeof(byte[]) });
                    if (loadMethod != null)
                    {
                        bool success = (bool)loadMethod.Invoke(null, new object[] { tex, bytes });
                        if (success) return tex;
                    }
                }
            }
            catch {}
        }
        return null;
    }

    // ==========================================
    // 3D LUSH JUNGLE ENVIRONMENT BUILDERS
    // ==========================================

    public GameObject BuildPalmTree(Transform parent, Vector3 pos)
    {
        CreateMaterialsIfNull();
        GameObject treeRoot = new GameObject("JunglePalmTree");
        if (parent != null) treeRoot.transform.SetParent(parent);
        treeRoot.transform.position = pos;

        // Curving trunk (3 segments)
        float trunkHeight = 6.5f;
        GameObject t1 = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        t1.transform.SetParent(treeRoot.transform);
        t1.transform.localPosition = new Vector3(0, 1.5f, 0);
        t1.transform.localScale = new Vector3(0.55f, 1.5f, 0.55f);
        t1.GetComponent<Renderer>().sharedMaterial = palmBarkMat;
        RemoveCollider(t1.GetComponent<Collider>());

        GameObject t2 = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        t2.transform.SetParent(treeRoot.transform);
        t2.transform.localPosition = new Vector3(0.25f, 4.2f, 0.1f);
        t2.transform.localScale = new Vector3(0.45f, 1.5f, 0.45f);
        t2.transform.localRotation = Quaternion.Euler(6f, 0, 5f);
        t2.GetComponent<Renderer>().sharedMaterial = palmBarkMat;
        RemoveCollider(t2.GetComponent<Collider>());

        // Palm Crown (8 large drooping green palm fronds)
        Vector3 topPos = new Vector3(0.4f, trunkHeight, 0.15f);
        for (int i = 0; i < 8; i++)
        {
            float angle = i * 45f;
            GameObject leaf = GameObject.CreatePrimitive(PrimitiveType.Cube);
            leaf.name = "PalmFrond_" + i;
            leaf.transform.SetParent(treeRoot.transform);
            leaf.transform.localPosition = topPos;
            leaf.transform.localRotation = Quaternion.Euler(28f, angle, 0);
            leaf.transform.Translate(Vector3.forward * 1.8f, Space.Self);
            leaf.transform.localScale = new Vector3(0.85f, 0.06f, 3.8f);
            leaf.GetComponent<Renderer>().sharedMaterial = palmLeafMat;
            RemoveCollider(leaf.GetComponent<Collider>());
        }

        // Coconuts cluster
        for (int c = 0; c < 3; c++)
        {
            GameObject coco = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            coco.transform.SetParent(treeRoot.transform);
            coco.transform.localPosition = topPos + new Vector3(Random.Range(-0.25f, 0.25f), -0.3f, Random.Range(-0.25f, 0.25f));
            coco.transform.localScale = new Vector3(0.35f, 0.42f, 0.35f);
            coco.GetComponent<Renderer>().sharedMaterial = palmBarkMat;
            RemoveCollider(coco.GetComponent<Collider>());
        }

        return treeRoot;
    }

    public GameObject BuildTemplePortalArch(Transform parent, Vector3 pos)
    {
        CreateMaterialsIfNull();
        GameObject arch = new GameObject("TemplePortalArch");
        if (parent != null) arch.transform.SetParent(parent);
        arch.transform.position = pos;

        // Left Giant Stone Pillar
        GameObject leftCol = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leftCol.transform.SetParent(arch.transform);
        leftCol.transform.localPosition = new Vector3(-4.4f, 3.5f, 0);
        leftCol.transform.localScale = new Vector3(1.6f, 7.0f, 1.8f);
        leftCol.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        // Right Giant Stone Pillar
        GameObject rightCol = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rightCol.transform.SetParent(arch.transform);
        rightCol.transform.localPosition = new Vector3(4.4f, 3.5f, 0);
        rightCol.transform.localScale = new Vector3(1.6f, 7.0f, 1.8f);
        rightCol.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        // Massive Ancient Stone Lintel / Arch
        GameObject lintel = GameObject.CreatePrimitive(PrimitiveType.Cube);
        lintel.transform.SetParent(arch.transform);
        lintel.transform.localPosition = new Vector3(0, 7.2f, 0);
        lintel.transform.localScale = new Vector3(10.5f, 1.6f, 2.2f);
        lintel.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        // GIANT CARVED MAYAN IDOL HEAD centered above portal
        GameObject idolHead = GameObject.CreatePrimitive(PrimitiveType.Cube);
        idolHead.name = "AncientIdolHead";
        idolHead.transform.SetParent(arch.transform);
        idolHead.transform.localPosition = new Vector3(0, 9.2f, -0.2f);
        idolHead.transform.localScale = new Vector3(3.2f, 2.6f, 2.0f);
        idolHead.GetComponent<Renderer>().sharedMaterial = ruinPillarMat;

        // Headdress Crest
        GameObject crest = GameObject.CreatePrimitive(PrimitiveType.Cube);
        crest.transform.SetParent(arch.transform);
        crest.transform.localPosition = new Vector3(0, 10.8f, -0.1f);
        crest.transform.localScale = new Vector3(4.0f, 0.8f, 1.6f);
        crest.GetComponent<Renderer>().sharedMaterial = goldMat;

        // Glowing Sapphire Idol Eyes
        for (int eye = -1; eye <= 1; eye += 2)
        {
            GameObject eyeObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            eyeObj.transform.SetParent(idolHead.transform);
            eyeObj.transform.localPosition = new Vector3(eye * 0.35f, 0.2f, -0.55f);
            eyeObj.transform.localScale = new Vector3(0.28f, 0.28f, 0.28f);
            eyeObj.GetComponent<Renderer>().sharedMaterial = gemBlueMat;
            RemoveCollider(eyeObj.GetComponent<Collider>());

            GameObject eyeLight = new GameObject("EyeGlow");
            eyeLight.transform.SetParent(eyeObj.transform);
            eyeLight.transform.localPosition = Vector3.zero;
            Light l = eyeLight.AddComponent<Light>();
            l.type = LightType.Point;
            l.color = new Color(0f, 0.8f, 1f);
            l.range = 5f;
            l.intensity = 1.8f;
        }

        // Hanging Vines draped from the lintel
        for (float vx = -3.5f; vx <= 3.5f; vx += 1.2f)
        {
            GameObject vine = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            vine.transform.SetParent(arch.transform);
            float vineLen = Random.Range(1.8f, 3.2f);
            vine.transform.localPosition = new Vector3(vx, 6.2f - (vineLen * 0.5f), Random.Range(-0.6f, 0.6f));
            vine.transform.localScale = new Vector3(0.1f, vineLen * 0.5f, 0.1f);
            vine.GetComponent<Renderer>().sharedMaterial = vineMat;
            RemoveCollider(vine.GetComponent<Collider>());
        }

        return arch;
    }

    public GameObject BuildPillarWithTorch(Transform parent, Vector3 pos)
    {
        CreateMaterialsIfNull();
        GameObject pillar = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        pillar.name = "PillarWithTorch";
        if (parent != null)
        {
            pillar.transform.SetParent(parent);
            pillar.transform.localPosition = new Vector3(pos.x, 2.0f, pos.z);
        }
        else
        {
            pillar.transform.position = new Vector3(pos.x, 2.0f, pos.z);
        }
        pillar.transform.localScale = new Vector3(0.75f, 2.0f, 0.75f);
        pillar.GetComponent<Renderer>().sharedMaterial = ruinPillarMat;

        // Ornate Stone Capital / Bowl
        GameObject bowl = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        bowl.transform.SetParent(pillar.transform);
        bowl.transform.localPosition = new Vector3(0, 1.05f, 0);
        bowl.transform.localScale = new Vector3(1.3f, 0.18f, 1.3f);
        bowl.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;
        RemoveCollider(bowl.GetComponent<Collider>());

        // Blazing Torch Fire
        GameObject fire = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        fire.name = "TorchFlame";
        fire.transform.SetParent(pillar.transform);
        fire.transform.localPosition = new Vector3(0f, 1.25f, 0f);
        fire.transform.localScale = new Vector3(0.6f, 0.45f, 0.6f);
        fire.GetComponent<Renderer>().sharedMaterial = torchFireMat;
        RemoveCollider(fire.GetComponent<Collider>());

        // Point Light for warm jungle torchlight
        GameObject lightObj = new GameObject("TorchLight");
        lightObj.transform.SetParent(fire.transform);
        lightObj.transform.localPosition = Vector3.zero;
        Light light = lightObj.AddComponent<Light>();
        light.type = LightType.Point;
        light.color = new Color(1.0f, 0.62f, 0.18f);
        light.range = 10f;
        light.intensity = 1.8f;

        return pillar;
    }

    public GameObject BuildWaterfallGorge(Transform parent, Vector3 pos, bool isLeft)
    {
        CreateMaterialsIfNull();
        GameObject gorge = new GameObject(isLeft ? "LeftWaterfallGorge" : "RightWaterfallGorge");
        if (parent != null) gorge.transform.SetParent(parent);
        gorge.transform.position = pos;

        // Deep canyon rock wall
        GameObject rock = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rock.transform.SetParent(gorge.transform);
        rock.transform.localPosition = new Vector3(0, -6f, 0);
        rock.transform.localScale = new Vector3(3.5f, 14f, 40f);
        rock.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;
        RemoveCollider(rock.GetComponent<Collider>());

        // Cascading Turquoise Waterfall Sheet
        GameObject water = GameObject.CreatePrimitive(PrimitiveType.Cube);
        water.transform.SetParent(gorge.transform);
        water.transform.localPosition = new Vector3(isLeft ? 1.4f : -1.4f, -4f, 0);
        water.transform.localScale = new Vector3(0.2f, 10f, 8f);
        water.GetComponent<Renderer>().sharedMaterial = waterMat;
        RemoveCollider(water.GetComponent<Collider>());

        // River at the bottom of the gorge
        GameObject river = GameObject.CreatePrimitive(PrimitiveType.Cube);
        river.transform.SetParent(gorge.transform);
        river.transform.localPosition = new Vector3(isLeft ? -4f : 4f, -12f, 0);
        river.transform.localScale = new Vector3(14f, 0.4f, 40f);
        river.GetComponent<Renderer>().sharedMaterial = waterMat;
        RemoveCollider(river.GetComponent<Collider>());

        return gorge;
    }

    // ==========================================
    // 3D COLLECTIBLE & HAZARD BUILDERS
    // ==========================================

    public GameObject BuildGoldCoin(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject coin = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        coin.name = "Coin";
        coin.tag = "Coin";
        coin.transform.position = position;
        coin.transform.localScale = new Vector3(0.75f, 0.09f, 0.75f);
        coin.transform.rotation = Quaternion.Euler(90f, 0f, 0f);

        coin.GetComponent<Renderer>().sharedMaterial = goldMat;
        Collider col = coin.GetComponent<Collider>();
        if (col != null) col.isTrigger = true;

        if (coin.GetComponent<CollectCoin>() == null) coin.AddComponent<CollectCoin>();
        return coin;
    }

    public GameObject BuildGem(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject gem = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        gem.name = "Gem";
        gem.tag = "Gem";
        gem.transform.position = position;
        gem.transform.localScale = new Vector3(0.6f, 0.85f, 0.6f);

        gem.GetComponent<Renderer>().sharedMaterial = gemBlueMat;
        Collider col = gem.GetComponent<Collider>();
        if (col != null) col.isTrigger = true;

        if (gem.GetComponent<GemCollect>() == null) gem.AddComponent<GemCollect>();
        return gem;
    }

    public GameObject BuildKey(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject keyRoot = new GameObject("GoldenKey");
        keyRoot.tag = "Key";
        keyRoot.transform.position = position;

        GameObject ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        ring.transform.SetParent(keyRoot.transform);
        ring.transform.localPosition = new Vector3(0f, 0.35f, 0f);
        ring.transform.localScale = new Vector3(0.45f, 0.06f, 0.45f);
        ring.GetComponent<Renderer>().sharedMaterial = goldMat;
        RemoveCollider(ring.GetComponent<Collider>());

        GameObject shaft = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        shaft.transform.SetParent(keyRoot.transform);
        shaft.transform.localPosition = new Vector3(0f, 0f, 0f);
        shaft.transform.localScale = new Vector3(0.12f, 0.38f, 0.12f);
        shaft.GetComponent<Renderer>().sharedMaterial = goldMat;
        RemoveCollider(shaft.GetComponent<Collider>());

        GameObject tooth = GameObject.CreatePrimitive(PrimitiveType.Cube);
        tooth.transform.SetParent(keyRoot.transform);
        tooth.transform.localPosition = new Vector3(0.14f, -0.2f, 0f);
        tooth.transform.localScale = new Vector3(0.2f, 0.14f, 0.08f);
        tooth.GetComponent<Renderer>().sharedMaterial = goldMat;
        RemoveCollider(tooth.GetComponent<Collider>());

        BoxCollider col = keyRoot.AddComponent<BoxCollider>();
        col.isTrigger = true;
        col.size = new Vector3(0.8f, 0.9f, 0.5f);
        keyRoot.AddComponent<KeyCollect>();

        return keyRoot;
    }

    public GameObject BuildTreasureChest(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject chestRoot = new GameObject("TreasureChest");
        chestRoot.transform.position = position;

        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.transform.SetParent(chestRoot.transform);
        body.transform.localPosition = new Vector3(0, 0.4f, 0);
        body.transform.localScale = new Vector3(1.3f, 0.8f, 0.9f);
        body.GetComponent<Renderer>().sharedMaterial = woodMat;
        RemoveCollider(body.GetComponent<Collider>());

        // Arched lid
        GameObject lid = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        lid.transform.SetParent(chestRoot.transform);
        lid.transform.localPosition = new Vector3(0, 0.85f, 0);
        lid.transform.localScale = new Vector3(0.88f, 0.65f, 0.88f);
        lid.transform.localRotation = Quaternion.Euler(0, 0, 90f);
        lid.GetComponent<Renderer>().sharedMaterial = woodMat;
        RemoveCollider(lid.GetComponent<Collider>());

        // Gold Corner Braces & Lock
        GameObject lockPlate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        lockPlate.transform.SetParent(chestRoot.transform);
        lockPlate.transform.localPosition = new Vector3(0, 0.55f, -0.48f);
        lockPlate.transform.localScale = new Vector3(0.25f, 0.35f, 0.1f);
        lockPlate.GetComponent<Renderer>().sharedMaterial = goldMat;
        RemoveCollider(lockPlate.GetComponent<Collider>());

        BoxCollider col = chestRoot.AddComponent<BoxCollider>();
        col.isTrigger = true;
        col.size = new Vector3(1.5f, 1.1f, 1.1f);

        PowerUpCollect pu = chestRoot.AddComponent<PowerUpCollect>();
        pu.powerUpType = PowerUpType.TreasureChest;

        return chestRoot;
    }

    public GameObject BuildPowerUp(PowerUpType type, Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject root = new GameObject("PowerUp_" + type.ToString());
        root.tag = "PowerUp";
        root.transform.position = position;

        GameObject visual;
        if (type == PowerUpType.Shield)
        {
            visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            visual.GetComponent<Renderer>().sharedMaterial = gemBlueMat;
            visual.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        }
        else if (type == PowerUpType.Magnet)
        {
            visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            visual.GetComponent<Renderer>().sharedMaterial = guardClothMat;
            visual.transform.localScale = new Vector3(0.7f, 0.18f, 0.7f);
        }
        else
        {
            visual = GameObject.CreatePrimitive(PrimitiveType.Cube);
            visual.GetComponent<Renderer>().sharedMaterial = goldMat;
            visual.transform.localScale = new Vector3(0.65f, 0.65f, 0.65f);
        }

        visual.transform.SetParent(root.transform);
        visual.transform.localPosition = Vector3.zero;
        RemoveCollider(visual.GetComponent<Collider>());

        SphereCollider col = root.AddComponent<SphereCollider>();
        col.isTrigger = true;
        col.radius = 0.85f;

        PowerUpCollect p = root.AddComponent<PowerUpCollect>();
        p.powerUpType = type;

        return root;
    }

    // ==========================================
    // 3D HAZARDS
    // ==========================================

    public GameObject BuildCrateObstacle(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject crate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        crate.name = "Obstacle_Crate";
        crate.tag = "Obstacle";
        crate.transform.position = position;
        crate.transform.localScale = new Vector3(1.5f, 1.4f, 1.5f);
        crate.GetComponent<Renderer>().sharedMaterial = woodMat;

        BoxCollider col = crate.GetComponent<BoxCollider>();
        col.isTrigger = true;

        crate.AddComponent<CollisionDetect>();
        ObstacleHazard h = crate.AddComponent<ObstacleHazard>();
        h.hazardType = HazardType.StaticCrate;

        return crate;
    }

    public GameObject BuildSpikeTrapObstacle(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject spikeRoot = new GameObject("Obstacle_SpikeTrap");
        spikeRoot.tag = "Obstacle";
        spikeRoot.transform.position = position;

        GameObject plate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        plate.transform.SetParent(spikeRoot.transform);
        plate.transform.localPosition = new Vector3(0, 0.05f, 0);
        plate.transform.localScale = new Vector3(1.9f, 0.1f, 1.9f);
        plate.GetComponent<Renderer>().sharedMaterial = ironSpikeMat;
        RemoveCollider(plate.GetComponent<Collider>());

        for (int x = -1; x <= 1; x += 2)
        {
            for (int z = -1; z <= 1; z += 2)
            {
                GameObject cone = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                cone.transform.SetParent(spikeRoot.transform);
                cone.transform.localPosition = new Vector3(x * 0.45f, 0.45f, z * 0.45f);
                cone.transform.localScale = new Vector3(0.22f, 0.45f, 0.22f);
                cone.GetComponent<Renderer>().sharedMaterial = ironSpikeMat;
                RemoveCollider(cone.GetComponent<Collider>());
            }
        }

        BoxCollider col = spikeRoot.AddComponent<BoxCollider>();
        col.isTrigger = true;
        col.size = new Vector3(1.9f, 0.9f, 1.9f);
        col.center = new Vector3(0, 0.45f, 0);

        spikeRoot.AddComponent<CollisionDetect>();
        ObstacleHazard h = spikeRoot.AddComponent<ObstacleHazard>();
        h.hazardType = HazardType.SpikeTrap;

        return spikeRoot;
    }

    public GameObject BuildRollingLogObstacle(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject logRoot = new GameObject("Obstacle_RollingLog");
        logRoot.tag = "Obstacle";
        logRoot.transform.position = position;

        GameObject logMesh = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        logMesh.transform.SetParent(logRoot.transform);
        logMesh.transform.localPosition = new Vector3(0, 1.45f, 0);
        logMesh.transform.localScale = new Vector3(0.55f, 4.2f, 0.55f);
        logMesh.transform.rotation = Quaternion.Euler(0, 0, 90f);
        logMesh.GetComponent<Renderer>().sharedMaterial = woodMat;
        RemoveCollider(logMesh.GetComponent<Collider>());

        GameObject leftPost = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leftPost.transform.SetParent(logRoot.transform);
        leftPost.transform.localPosition = new Vector3(-3.8f, 1.0f, 0);
        leftPost.transform.localScale = new Vector3(0.45f, 2.3f, 0.45f);
        leftPost.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        GameObject rightPost = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rightPost.transform.SetParent(logRoot.transform);
        rightPost.transform.localPosition = new Vector3(3.8f, 1.0f, 0);
        rightPost.transform.localScale = new Vector3(0.45f, 2.3f, 0.45f);
        rightPost.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        BoxCollider col = logRoot.AddComponent<BoxCollider>();
        col.isTrigger = true;
        col.size = new Vector3(7.5f, 0.75f, 0.75f);
        col.center = new Vector3(0, 1.45f, 0);

        logRoot.AddComponent<CollisionDetect>();
        ObstacleHazard h = logRoot.AddComponent<ObstacleHazard>();
        h.hazardType = HazardType.RollingLog;

        return logRoot;
    }

    public GameObject BuildRollingBoulderObstacle(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject boulder = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        boulder.name = "Obstacle_RollingBoulder";
        boulder.tag = "Obstacle";
        boulder.transform.position = position;
        boulder.transform.localScale = new Vector3(2.3f, 2.3f, 2.3f);
        boulder.GetComponent<Renderer>().sharedMaterial = ruinPillarMat;

        SphereCollider col = boulder.GetComponent<SphereCollider>();
        col.isTrigger = true;

        boulder.AddComponent<CollisionDetect>();
        ObstacleHazard h = boulder.AddComponent<ObstacleHazard>();
        h.hazardType = HazardType.RollingBoulder;
        h.boulderRollSpeed = 6f;

        return boulder;
    }

    public GameObject BuildSpearGuardObstacle(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject guardRoot = new GameObject("Obstacle_SpearGuard");
        guardRoot.tag = "Obstacle";
        guardRoot.transform.position = position;

        GameObject torso = GameObject.CreatePrimitive(PrimitiveType.Cube);
        torso.transform.SetParent(guardRoot.transform);
        torso.transform.localPosition = new Vector3(0, 1.0f, 0);
        torso.transform.localScale = new Vector3(0.85f, 1.1f, 0.55f);
        torso.GetComponent<Renderer>().sharedMaterial = guardClothMat;
        RemoveCollider(torso.GetComponent<Collider>());

        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.transform.SetParent(guardRoot.transform);
        head.transform.localPosition = new Vector3(0, 1.85f, 0);
        head.transform.localScale = new Vector3(0.55f, 0.55f, 0.55f);
        head.GetComponent<Renderer>().sharedMaterial = goldMat;
        RemoveCollider(head.GetComponent<Collider>());

        GameObject spear = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        spear.transform.SetParent(guardRoot.transform);
        spear.transform.localPosition = new Vector3(0.55f, 1.3f, 0.2f);
        spear.transform.localScale = new Vector3(0.06f, 1.3f, 0.06f);
        spear.GetComponent<Renderer>().sharedMaterial = ironSpikeMat;
        RemoveCollider(spear.GetComponent<Collider>());

        BoxCollider col = guardRoot.AddComponent<BoxCollider>();
        col.isTrigger = true;
        col.size = new Vector3(1.5f, 2.2f, 0.85f);
        col.center = new Vector3(0, 1.1f, 0);

        guardRoot.AddComponent<CollisionDetect>();
        ObstacleHazard h = guardRoot.AddComponent<ObstacleHazard>();
        h.hazardType = HazardType.SpearGuard;

        return guardRoot;
    }

    public GameObject BuildExplorerPlayer(Vector3 position)
    {
        CreateMaterialsIfNull();
        GameObject playerRoot = new GameObject("Player");
        playerRoot.tag = "Player";
        playerRoot.transform.position = position;

        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        body.name = "BodyMesh";
        body.transform.SetParent(playerRoot.transform);
        body.transform.localPosition = new Vector3(0, 1.0f, 0);
        body.transform.localScale = new Vector3(0.72f, 0.85f, 0.72f);
        body.GetComponent<Renderer>().sharedMaterial = explorerMat;
        RemoveCollider(body.GetComponent<Collider>());

        GameObject hatBrim = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        hatBrim.transform.SetParent(playerRoot.transform);
        hatBrim.transform.localPosition = new Vector3(0, 1.95f, 0);
        hatBrim.transform.localScale = new Vector3(0.98f, 0.04f, 0.98f);
        hatBrim.GetComponent<Renderer>().sharedMaterial = woodMat;
        RemoveCollider(hatBrim.GetComponent<Collider>());

        GameObject hatTop = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        hatTop.transform.SetParent(playerRoot.transform);
        hatTop.transform.localPosition = new Vector3(0, 2.12f, 0);
        hatTop.transform.localScale = new Vector3(0.62f, 0.18f, 0.62f);
        hatTop.GetComponent<Renderer>().sharedMaterial = woodMat;
        RemoveCollider(hatTop.GetComponent<Collider>());

        GameObject scarf = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        scarf.transform.SetParent(playerRoot.transform);
        scarf.transform.localPosition = new Vector3(0, 1.6f, 0);
        scarf.transform.localScale = new Vector3(0.68f, 0.08f, 0.68f);
        scarf.GetComponent<Renderer>().sharedMaterial = guardClothMat;
        RemoveCollider(scarf.GetComponent<Collider>());

        GameObject pack = GameObject.CreatePrimitive(PrimitiveType.Cube);
        pack.transform.SetParent(playerRoot.transform);
        pack.transform.localPosition = new Vector3(0, 1.15f, -0.42f);
        pack.transform.localScale = new Vector3(0.55f, 0.6f, 0.35f);
        pack.GetComponent<Renderer>().sharedMaterial = woodMat;
        RemoveCollider(pack.GetComponent<Collider>());

        GameObject shieldObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        shieldObj.name = "ShieldBubble";
        shieldObj.transform.SetParent(playerRoot.transform);
        shieldObj.transform.localPosition = new Vector3(0, 1.1f, 0);
        shieldObj.transform.localScale = new Vector3(2.4f, 2.4f, 2.4f);
        shieldObj.GetComponent<Renderer>().sharedMaterial = shieldMat;
        RemoveCollider(shieldObj.GetComponent<Collider>());
        shieldObj.SetActive(false);

        CapsuleCollider cap = playerRoot.AddComponent<CapsuleCollider>();
        cap.center = new Vector3(0, 1.0f, 0);
        cap.height = 2.0f;
        cap.radius = 0.45f;

        Rigidbody rb = playerRoot.AddComponent<Rigidbody>();
        rb.isKinematic = true;

        PlayerMovement movement = playerRoot.AddComponent<PlayerMovement>();
        movement.shieldBubbleVisual = shieldObj;

        return playerRoot;
    }

    // ==========================================
    // EXTRA DENSE JUNGLE DETAIL HELPERS
    // ==========================================

    private static void RemoveCollider(Collider collider)
    {
        if (collider == null) return;

        if (Application.isPlaying)
            Destroy(collider);
        else
            DestroyImmediate(collider);
    }

    private GameObject CreateDecorPrimitive(PrimitiveType type, string objectName, Transform parent,
        Vector3 localPosition, Vector3 localScale, Material material, Vector3 localEuler = default(Vector3))
    {
        GameObject item = GameObject.CreatePrimitive(type);
        item.name = objectName;
        item.transform.SetParent(parent, false);
        item.transform.localPosition = localPosition;
        item.transform.localRotation = Quaternion.Euler(localEuler);
        item.transform.localScale = localScale;
        Renderer r = item.GetComponent<Renderer>();
        if (r != null) r.sharedMaterial = material;
        Collider c = item.GetComponent<Collider>();
        RemoveCollider(c);
        return item;
    }

    private void BuildJungleBush(Transform parent, Vector3 position, float size)
    {
        GameObject root = new GameObject("DenseJungleBush");
        root.transform.SetParent(parent, false);
        root.transform.localPosition = position;
        for (int i = 0; i < 7; i++)
        {
            float angle = i * 51.4f;
            float radius = (i == 0) ? 0f : size * 0.34f;
            Vector3 offset = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad) * radius,
                Random.Range(0.12f, 0.48f) * size,
                Mathf.Sin(angle * Mathf.Deg2Rad) * radius);
            float s = Random.Range(0.55f, 0.9f) * size;
            CreateDecorPrimitive(PrimitiveType.Sphere, "LeafyBushCluster", root.transform,
                offset, new Vector3(s, s * 0.72f, s), (i % 2 == 0) ? palmLeafMat : darkLeafMat);
        }
    }

    private void BuildFern(Transform parent, Vector3 position, float size)
    {
        GameObject root = new GameObject("JungleFern");
        root.transform.SetParent(parent, false);
        root.transform.localPosition = position;
        CreateDecorPrimitive(PrimitiveType.Sphere, "FernCenter", root.transform,
            new Vector3(0, 0.28f * size, 0), new Vector3(0.38f, 0.32f, 0.38f) * size, fernMat);
        for (int i = 0; i < 9; i++)
        {
            float angle = i * 40f;
            float length = Random.Range(0.75f, 1.25f) * size;
            Vector3 offset = new Vector3(Mathf.Sin(angle * Mathf.Deg2Rad) * length * 0.48f,
                0.42f * size + length * 0.16f,
                Mathf.Cos(angle * Mathf.Deg2Rad) * length * 0.48f);
            CreateDecorPrimitive(PrimitiveType.Sphere, "FernFrond", root.transform,
                offset, new Vector3(0.16f, 0.075f, length), fernMat,
                new Vector3(-28f, angle, 0f));
        }
    }

    private void BuildJungleCanopyTree(Transform parent, Vector3 position, float height)
    {
        GameObject root = new GameObject("BroadleafJungleTree");
        root.transform.SetParent(parent, false);
        root.transform.localPosition = position;
        CreateDecorPrimitive(PrimitiveType.Cylinder, "TreeTrunk", root.transform,
            new Vector3(0, height * 0.42f, 0), new Vector3(0.34f, height * 0.42f, 0.34f), palmBarkMat,
            new Vector3(0, 0, Random.Range(-5f, 5f)));
        for (int i = 0; i < 6; i++)
        {
            float angle = i * 60f;
            Vector3 offset = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad) * height * 0.19f,
                height * 0.83f + Random.Range(-0.25f, 0.3f),
                Mathf.Sin(angle * Mathf.Deg2Rad) * height * 0.19f);
            float canopySize = height * Random.Range(0.22f, 0.31f);
            CreateDecorPrimitive(PrimitiveType.Sphere, "TreeCanopy", root.transform,
                offset, new Vector3(canopySize * 1.35f, canopySize * 0.72f, canopySize),
                (i % 2 == 0) ? darkLeafMat : palmLeafMat);
        }
    }

    private void BuildJungleRockCluster(Transform parent, Vector3 position, float size)
    {
        GameObject root = new GameObject("MossyJungleRocks");
        root.transform.SetParent(parent, false);
        root.transform.localPosition = position;
        for (int i = 0; i < 4; i++)
        {
            Vector3 offset = new Vector3((i - 1.5f) * size * 0.35f,
                Random.Range(0.15f, 0.45f) * size,
                Random.Range(-0.25f, 0.25f) * size);
            float scale = Random.Range(0.55f, 1f) * size;
            CreateDecorPrimitive(PrimitiveType.Sphere, "MossyRock", root.transform,
                offset, new Vector3(scale * 1.1f, scale * 0.72f, scale), jungleRockMat,
                new Vector3(Random.Range(-12f, 12f), Random.Range(0f, 360f), Random.Range(-12f, 12f)));
        }
    }

    private void BuildHangingVine(Transform parent, Vector3 position, float length)
    {
        CreateDecorPrimitive(PrimitiveType.Cylinder, "HangingJungleVine", parent,
            position + new Vector3(0, -length * 0.5f, 0), new Vector3(0.035f, length * 0.5f, 0.035f),
            vineMat, new Vector3(Random.Range(-8f, 8f), 0, Random.Range(-8f, 8f)));
    }

    // ==========================================
    // COMPLETE JUNGLE RUINS TRACK SEGMENTS
    // ==========================================

    public GameObject BuildSegmentBase(string name, float length = 50f)
    {
        CreateMaterialsIfNull();
        GameObject seg = new GameObject(name);

        // Dark forest floor beyond the playable stone path.
        for (int side = -1; side <= 1; side += 2)
        {
            GameObject forestFloor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            forestFloor.name = side < 0 ? "LeftJungleFloor" : "RightJungleFloor";
            forestFloor.transform.SetParent(seg.transform, false);
            forestFloor.transform.localPosition = new Vector3(side * 10.2f, -0.82f, length * 0.5f);
            forestFloor.transform.localScale = new Vector3(11.5f, 0.55f, length + 4f);
            forestFloor.GetComponent<Renderer>().sharedMaterial = jungleGroundMat;
            RemoveCollider(forestFloor.GetComponent<Collider>());
        }

        // Ancient stone running path and raised mossy borders.
        GameObject road = GameObject.CreatePrimitive(PrimitiveType.Cube);
        road.name = "StoneRoad";
        road.transform.SetParent(seg.transform, false);
        road.transform.localPosition = new Vector3(0, -0.25f, length * 0.5f);
        road.transform.localScale = new Vector3(8.0f, 0.5f, length);
        road.GetComponent<Renderer>().sharedMaterial = stoneRoadMat;

        GameObject leftCurb = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leftCurb.name = "LeftMossyCurb";
        leftCurb.transform.SetParent(seg.transform, false);
        leftCurb.transform.localPosition = new Vector3(-4.2f, 0.25f, length * 0.5f);
        leftCurb.transform.localScale = new Vector3(0.7f, 0.8f, length);
        leftCurb.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        GameObject rightCurb = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rightCurb.name = "RightMossyCurb";
        rightCurb.transform.SetParent(seg.transform, false);
        rightCurb.transform.localPosition = new Vector3(4.2f, 0.25f, length * 0.5f);
        rightCurb.transform.localScale = new Vector3(0.7f, 0.8f, length);
        rightCurb.GetComponent<Renderer>().sharedMaterial = mossyStoneMat;

        // Dense tropical vegetation stays outside the runner's collision lanes.
        for (float z = 3f; z < length; z += 7.5f)
        {
            float jitter = Random.Range(-1.2f, 1.2f);
            BuildJungleCanopyTree(seg.transform, new Vector3(-11.5f, -0.45f, z + jitter), Random.Range(7.5f, 10f));
            BuildJungleCanopyTree(seg.transform, new Vector3(11.5f, -0.45f, z + 3.5f + jitter), Random.Range(7.5f, 10f));
            BuildJungleBush(seg.transform, new Vector3(-6.0f, -0.45f, z + 2f), Random.Range(1.1f, 1.8f));
            BuildJungleBush(seg.transform, new Vector3(6.0f, -0.45f, z + 5f), Random.Range(1.1f, 1.8f));
            BuildFern(seg.transform, new Vector3(-5.2f, -0.45f, z + 4f), Random.Range(0.8f, 1.25f));
            BuildFern(seg.transform, new Vector3(5.2f, -0.45f, z + 1f), Random.Range(0.8f, 1.25f));
            BuildJungleRockCluster(seg.transform, new Vector3(-8.0f, -0.45f, z + 1.5f), Random.Range(1.0f, 1.7f));
            BuildJungleRockCluster(seg.transform, new Vector3(8.0f, -0.45f, z + 5.0f), Random.Range(1.0f, 1.7f));
        }

        // Palm trees and torch pillars form a temple trail, but are spaced apart.
        for (float z = 6f; z < length; z += 16f)
        {
            BuildPalmTree(seg.transform, new Vector3(-6.8f, 0, z));
            BuildPalmTree(seg.transform, new Vector3(6.8f, 0, z + 8f));
        }
        for (float z = 10f; z < length; z += 18f)
        {
            BuildPillarWithTorch(seg.transform, new Vector3(-4.6f, 0, z));
            BuildPillarWithTorch(seg.transform, new Vector3(4.6f, 0, z));
        }

        // Vines hang from the outer canopy edge to create a layered jungle silhouette.
        for (float z = 5f; z < length; z += 12f)
        {
            BuildHangingVine(seg.transform, new Vector3(-7.2f, 7.0f, z), Random.Range(2.0f, 4.0f));
            BuildHangingVine(seg.transform, new Vector3(7.2f, 7.0f, z + 4f), Random.Range(2.0f, 4.0f));
        }

        // Waterfall canyon walls and river beneath the jungle path.
        BuildWaterfallGorge(seg.transform, new Vector3(-9.0f, 0, length * 0.5f), true);
        BuildWaterfallGorge(seg.transform, new Vector3(9.0f, 0, length * 0.5f), false);

        return seg;
    }

    public GameObject CreateSegmentA()
    {
        GameObject seg = BuildSegmentBase("SegmentA_CoinRunway");

        // Temple Portal Archway at start of segment
        BuildTemplePortalArch(seg.transform, new Vector3(0, 0, 12f));

        for (float z = 16f; z <= 44f; z += 4f)
        {
            GameObject coin = BuildGoldCoin(new Vector3(0f, 0.6f, z));
            coin.transform.SetParent(seg.transform);
        }

        GameObject gem = BuildGem(new Vector3(2.5f, 0.8f, 28f));
        gem.transform.SetParent(seg.transform);

        return seg;
    }

    public GameObject CreateSegmentB()
    {
        GameObject seg = BuildSegmentBase("SegmentB_RollingLog");

        // Temple Archway with Spiked Rolling Log (MUST SLIDE UNDER!)
        BuildTemplePortalArch(seg.transform, new Vector3(0, 0, 24f));
        GameObject log = BuildRollingLogObstacle(new Vector3(0, 0, 25f));
        log.transform.SetParent(seg.transform);

        // Guide coins under log
        for (float z = 18f; z <= 30f; z += 2.5f)
        {
            GameObject c = BuildGoldCoin(new Vector3(0, 0.4f, z));
            c.transform.SetParent(seg.transform);
        }

        GameObject crate1 = BuildCrateObstacle(new Vector3(-2.5f, 0.7f, 38f));
        crate1.transform.SetParent(seg.transform);

        return seg;
    }

    public GameObject CreateSegmentC()
    {
        GameObject seg = BuildSegmentBase("SegmentC_ChasmJump");

        GameObject spikes = BuildSpikeTrapObstacle(new Vector3(0, 0, 22f));
        spikes.transform.SetParent(seg.transform);

        float[] heights = new float[] { 0.6f, 1.4f, 2.2f, 1.4f, 0.6f };
        for (int i = 0; i < heights.Length; i++)
        {
            GameObject c = BuildGoldCoin(new Vector3(0, heights[i], 17f + i * 2.5f));
            c.transform.SetParent(seg.transform);
        }

        GameObject key = BuildKey(new Vector3(-2.5f, 0.8f, 36f));
        key.transform.SetParent(seg.transform);

        return seg;
    }

    public GameObject CreateSegmentD()
    {
        GameObject seg = BuildSegmentBase("SegmentD_BoulderAndGuard");

        GameObject boulder = BuildRollingBoulderObstacle(new Vector3(-2.5f, 1.1f, 30f));
        boulder.transform.SetParent(seg.transform);

        GameObject guard = BuildSpearGuardObstacle(new Vector3(0f, 0f, 40f));
        guard.transform.SetParent(seg.transform);

        for (float z = 15f; z <= 42f; z += 4f)
        {
            GameObject c = BuildGoldCoin(new Vector3(2.5f, 0.6f, z));
            c.transform.SetParent(seg.transform);
        }

        GameObject magnet = BuildPowerUp(PowerUpType.Magnet, new Vector3(2.5f, 0.8f, 28f));
        magnet.transform.SetParent(seg.transform);

        return seg;
    }

    public GameObject CreateSegmentE()
    {
        GameObject seg = BuildSegmentBase("SegmentE_TreasureCache");

        BuildTemplePortalArch(seg.transform, new Vector3(0, 0, 10f));

        GameObject crateL = BuildCrateObstacle(new Vector3(-2.5f, 0.7f, 20f));
        crateL.transform.SetParent(seg.transform);

        GameObject crateR = BuildCrateObstacle(new Vector3(2.5f, 0.7f, 20f));
        crateR.transform.SetParent(seg.transform);

        GameObject shieldPU = BuildPowerUp(PowerUpType.Shield, new Vector3(0f, 0.8f, 15f));
        shieldPU.transform.SetParent(seg.transform);

        GameObject chest = BuildTreasureChest(new Vector3(0f, 0f, 32f));
        chest.transform.SetParent(seg.transform);

        GameObject gem1 = BuildGem(new Vector3(-1.5f, 0.6f, 35f));
        gem1.transform.SetParent(seg.transform);
        GameObject gem2 = BuildGem(new Vector3(1.5f, 0.6f, 35f));
        gem2.transform.SetParent(seg.transform);

        return seg;
    }
}
