using System.Collections;
using UnityEngine;

/// <summary>
/// KeyCollect: Handles picking up ancient golden keys to unlock ruins treasure chests.
/// </summary>
public class KeyCollect : MonoBehaviour
{
    [SerializeField] private bool collectedKey = false;
    [SerializeField] public AudioSource keyFx;

    void Update()
    {
        if (!collectedKey)
        {
            transform.Rotate(0, 2f, 0, Space.World);
        }
        else
        {
            transform.Translate(Vector3.up * Time.deltaTime * 6f, Space.World);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (collectedKey) return;
        if (!other.CompareTag("Player") && other.GetComponent<PlayerMovement>() == null) return;

        collectedKey = true;
        MasterLevelInfo.keyCount += 1;

        if (keyFx != null)
        {
            keyFx.Play();
        }
        else if (SoundManager.Instance != null)
        {
            SoundManager.Instance.PlayKey();
        }

        StartCoroutine(ShrinkAndDestroy());
    }

    private IEnumerator ShrinkAndDestroy()
    {
        Vector3 initialScale = transform.localScale;
        float elapsed = 0f;
        while (elapsed < 0.45f)
        {
            elapsed += Time.deltaTime;
            transform.localScale = Vector3.Lerp(initialScale, Vector3.zero, elapsed / 0.45f);
            yield return null;
        }
        gameObject.SetActive(false);
    }
}
