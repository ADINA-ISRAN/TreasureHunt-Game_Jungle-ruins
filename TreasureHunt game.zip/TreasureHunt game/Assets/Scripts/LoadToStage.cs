using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// LoadToStage: Controls the Information / Instructions scene.
/// Displays lane controls, jump/slide instructions, animates LOADING text,
/// and automatically transitions to the Gameplay scene.
/// </summary>
public class LoadToStage : MonoBehaviour
{
    [SerializeField] public GameObject fadeOut;
    [SerializeField] public Text loadingText;
    [SerializeField] public float waitDuration = 3f;

    void Start()
    {
        StartCoroutine(LoadLevel());
    }

    void Update()
    {
        // Allow tap or key to skip immediately
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return) || Input.GetMouseButtonDown(0))
        {
            StopAllCoroutines();
            StartCoroutine(ImmediateLoad());
        }

        if (loadingText != null)
        {
            int dots = (int)(Time.time * 3f) % 4;
            loadingText.text = "LOADING" + new string('.', dots);
        }
    }

    IEnumerator LoadLevel()
    {
        yield return new WaitForSeconds(waitDuration);

        if (fadeOut != null)
        {
            fadeOut.SetActive(true);
        }

        yield return new WaitForSeconds(1.2f);
        ExecuteLoad();
    }

    IEnumerator ImmediateLoad()
    {
        if (fadeOut != null) fadeOut.SetActive(true);
        yield return new WaitForSeconds(0.4f);
        ExecuteLoad();
    }

    private void ExecuteLoad()
    {
        if (Application.CanStreamedLevelBeLoaded("GamePlay"))
        {
            SceneManager.LoadScene("GamePlay");
        }
        else if (SceneManager.sceneCountInBuildSettings > 3)
        {
            SceneManager.LoadScene(3);
        }
        else
        {
            SceneManager.LoadScene(0);
        }
    }
}
