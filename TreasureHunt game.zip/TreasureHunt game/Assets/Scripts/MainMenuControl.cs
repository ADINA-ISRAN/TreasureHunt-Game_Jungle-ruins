using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// MainMenuControl: Controls the Main Menu Scene.
/// Displays high scores, saved totals (Coins, Gems, Keys), triggers camera anim,
/// plays sound effects, and transitions to StageSelect.
/// </summary>
public class MainMenuControl : MonoBehaviour
{
    [Header("Fade & UI Objects")]
    [SerializeField] public GameObject fadeOut;
    [SerializeField] public GameObject fadeIn;
    [SerializeField] public GameObject bigButton;
    [SerializeField] public GameObject animCam;
    [SerializeField] public GameObject mainCam;
    [SerializeField] public GameObject menuControls;

    [Header("HUD Displays")]
    [SerializeField] public Text coinTotalText;
    [SerializeField] public Text gemTotalText;
    [SerializeField] public Text keyTotalText;
    [SerializeField] public Text bestDistanceText;

    [Header("Audio")]
    [SerializeField] public AudioSource buttonSelect;

    [Header("Buttons")]
    [SerializeField] public Button startButton;

    void Start()
    {
        if (startButton == null)
        {
            GameObject btnObj = GameObject.Find("StartGameBtn");
            if (btnObj != null) startButton = btnObj.GetComponent<Button>();
        }
        if (startButton != null)
        {
            startButton.onClick.RemoveAllListeners();
            startButton.onClick.AddListener(StartGame);
        }

        StartCoroutine(FadeInTurnOff());
        RefreshSavedTotals();
    }

    void Update()
    {
        // Allow Space or Return to start immediately
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
        {
            StartGame();
        }
    }

    public void RefreshSavedTotals()
    {
        SaveLoad.LoadAll();
        if (coinTotalText != null) coinTotalText.text = SaveLoad.loadedCoins.ToString();
        if (gemTotalText != null) gemTotalText.text = SaveLoad.loadedGems.ToString();
        if (keyTotalText != null) keyTotalText.text = SaveLoad.loadedKeys.ToString();
        if (bestDistanceText != null) bestDistanceText.text = SaveLoad.loadedDistance.ToString() + " m";
    }

    public void MenuBeginButton()
    {
        StartCoroutine(AnimCamRoutine());
    }

    IEnumerator AnimCamRoutine()
    {
        if (buttonSelect != null) buttonSelect.Play();
        else if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();

        if (bigButton != null) bigButton.SetActive(false);
        if (animCam != null) animCam.SetActive(true);
        if (mainCam != null) mainCam.SetActive(false);

        yield return new WaitForSeconds(1.5f);

        if (menuControls != null) menuControls.SetActive(true);
    }

    public void StartGame()
    {
        StartCoroutine(StartButton());
    }

    IEnumerator StartButton()
    {
        if (buttonSelect != null) buttonSelect.Play();
        else if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();

        if (fadeOut != null) fadeOut.SetActive(true);
        yield return new WaitForSeconds(0.8f);

        // Transition to StageSelect (Scene 1 in build order)
        if (Application.CanStreamedLevelBeLoaded("StageSelect"))
        {
            SceneManager.LoadScene("StageSelect");
        }
        else if (SceneManager.sceneCountInBuildSettings > 1)
        {
            SceneManager.LoadScene(1);
        }
        else
        {
            SceneManager.LoadScene(0);
        }
    }

    IEnumerator FadeInTurnOff()
    {
        if (fadeIn != null) fadeIn.SetActive(true);
        yield return new WaitForSeconds(0.05f);
        RefreshSavedTotals();
        yield return new WaitForSeconds(0.8f);
        if (fadeIn != null) fadeIn.SetActive(false);
    }
}
