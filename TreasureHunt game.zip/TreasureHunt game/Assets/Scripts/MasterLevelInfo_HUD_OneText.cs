using UnityEngine;
using UnityEngine.UI;

public class MasterLevelInfo : MonoBehaviour
{
    public static int coinCount = 0;
    public static int gemCount = 0;
    public static int keyCount = 0;
    public static int distanceRun = 0;
    public static float scoreMultiplier = 1f;

    [Header("HUD Displays")]
    [SerializeField] public GameObject coinDisplay;
    [SerializeField] public GameObject gemDisplay;
    [SerializeField] public GameObject keyDisplay;
    [SerializeField] public GameObject runDisplay;

    void Start()
    {
        coinCount = 0;
        gemCount = 0;
        keyCount = 0;
        distanceRun = 0;
        scoreMultiplier = 1f;
        RefreshHud();
    }

    void Update()
    {
        RefreshHud();
    }

    private void RefreshHud()
    {
        SetDisplayText(coinDisplay, "COINS: " + coinCount);
        SetDisplayText(gemDisplay, "GEMS: " + gemCount);
        SetDisplayText(keyDisplay, "KEYS: " + keyCount);
        SetDisplayText(runDisplay, "DISTANCE: " + distanceRun + " m");
    }

    private void SetDisplayText(GameObject displayObj, string value)
    {
        if (displayObj == null) return;

        Text legacyText = displayObj.GetComponent<Text>();
        if (legacyText != null)
        {
            legacyText.text = value;
            return;
        }

        Component tmp = displayObj.GetComponent("TextMeshProUGUI");
        if (tmp == null) tmp = displayObj.GetComponent("TMP_Text");
        if (tmp != null)
        {
            var textProperty = tmp.GetType().GetProperty("text");
            if (textProperty != null) textProperty.SetValue(tmp, value, null);
        }
    }
}
