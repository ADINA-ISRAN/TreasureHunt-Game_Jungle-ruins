using UnityEngine;

public enum HazardType
{
    StaticCrate,
    SpikeTrap,
    RollingLog,
    RollingBoulder,
    CollapsingBridge,
    SpearGuard
}

/// <summary>
/// ObstacleHazard: Custom hazard behaviors for the 6 hazards described in the presentation:
/// Crates, Spikes, Rolling Logs, Falling/Rolling Boulders, Collapsing Bridge gaps, and Guards.
/// </summary>
public class ObstacleHazard : MonoBehaviour
{
    public HazardType hazardType = HazardType.StaticCrate;

    [Header("Rolling Log Settings")]
    public float logSpinSpeed = 360f;

    [Header("Rolling Boulder Settings")]
    public float boulderRollSpeed = 10f;
    public float rollRotation = 250f;
    public bool rollsTowardPlayer = true;

    [Header("Spear Guard Settings")]
    public float patrolSpeed = 2f;
    public float patrolDistance = 1.2f;
    private Vector3 initialPos;

    void Start()
    {
        initialPos = transform.position;
    }

    void Update()
    {
        switch (hazardType)
        {
            case HazardType.RollingLog:
                // Rapidly spin along its horizontal axis
                transform.Rotate(logSpinSpeed * Time.deltaTime, 0, 0, Space.Self);
                break;

            case HazardType.RollingBoulder:
                // Roll along the Z track toward the player
                if (rollsTowardPlayer)
                {
                    transform.Translate(Vector3.back * boulderRollSpeed * Time.deltaTime, Space.World);
                }
                transform.Rotate(rollRotation * Time.deltaTime, 0, 0, Space.World);
                break;

            case HazardType.SpearGuard:
                // Guard patrols back and forth slightly in lane
                float offset = Mathf.PingPong(Time.time * patrolSpeed, patrolDistance * 2f) - patrolDistance;
                transform.position = new Vector3(initialPos.x + offset, initialPos.y, initialPos.z);
                break;

            case HazardType.CollapsingBridge:
            case HazardType.SpikeTrap:
            case HazardType.StaticCrate:
            default:
                break;
        }
    }
}
