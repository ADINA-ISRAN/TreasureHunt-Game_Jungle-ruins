using System.Collections;
using UnityEngine;

/// <summary>
/// PlayerMovement: Controls endless auto-forward running, smooth lane shifting
/// (A/D or Arrows or Touch Swipes), Jumping (Space/Up/Swipe Up), Sliding (S/Down/Swipe Down),
/// and distance scoring with power-up handling (Shield, Magnet, Speed Boost).
/// </summary>
public class PlayerMovement : MonoBehaviour
{
    [Header("Speed Settings")]
    public float playerSpeed = 12f;
    public float horizontalSpeed = 10f;
    public float rightLimit = 3.5f;
    public float leftLimit = -3.5f;

    [Header("Jump & Gravity")]
    public float jumpForce = 9.5f;
    public float gravity = 25f;
    private float verticalVelocity = 0f;
    private bool isGrounded = true;
    private float groundY = 0f;

    [Header("Slide Settings")]
    public float slideDuration = 0.85f;
    public bool isSliding = false;
    private Vector3 originalColliderCenter;
    private float originalColliderHeight;

    [Header("State Tracking")]
    [SerializeField] private bool isRunning = false;
    public bool isAlive = true;

    [Header("Power-ups")]
    public bool hasShield = false;
    public GameObject shieldBubbleVisual;
    public bool hasMagnet = false;
    public float magnetRadius = 8f;
    public float originalSpeed;

    [Header("Audio & Animations")]
    public AudioSource jumpAudio;
    public AudioSource slideAudio;
    private Animator animator;
    private CharacterController controller;
    private CapsuleCollider capsule;

    // Mobile Swipe & Mouse Drag Detection
    private Vector2 touchStartPos;
    private bool isTouching = false;
    private const float MIN_SWIPE_DISTANCE = 30f;

    void Awake()
    {
        originalSpeed = playerSpeed;
        controller = GetComponent<CharacterController>();
        capsule = GetComponent<CapsuleCollider>();
        animator = GetComponentInChildren<Animator>();

        if (capsule != null)
        {
            originalColliderCenter = capsule.center;
            originalColliderHeight = capsule.height;
        }
        else if (controller != null)
        {
            originalColliderCenter = controller.center;
            originalColliderHeight = controller.height;
        }
        groundY = transform.position.y;
    }

    void Update()
    {
        if (!isAlive) return;

        // Distance counter loop from presentation
        if (!isRunning)
        {
            isRunning = true;
            StartCoroutine(AddDistance());
        }

        // 1. Auto-Forward Movement
        transform.Translate(Vector3.forward * Time.deltaTime * playerSpeed, Space.World);

        // 2. Process Controls (Keyboard & Swipes)
        HandleKeyboardInput();
        HandleTouchAndMouseSwipe();

        // 3. Jump & Vertical Physics
        HandleJumpPhysics();

        // 4. Magnet Attractor
        if (hasMagnet)
        {
            AttractNearbyCoins();
        }

        // 5. Update Visual Shield
        if (shieldBubbleVisual != null)
        {
            shieldBubbleVisual.SetActive(hasShield);
        }
    }

    private void HandleKeyboardInput()
    {
        // Horizontal Movement (Left / Right)
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            if (transform.position.x > leftLimit)
            {
                transform.Translate(Vector3.left * Time.deltaTime * horizontalSpeed, Space.World);
            }
        }
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            if (transform.position.x < rightLimit)
            {
                transform.Translate(Vector3.right * Time.deltaTime * horizontalSpeed, Space.World);
            }
        }

        // Jump (Space / W / Up Arrow)
        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) && isGrounded && !isSliding)
        {
            TriggerJump();
        }

        // Slide (S / Down Arrow)
        if ((Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow)) && isGrounded && !isSliding)
        {
            StartCoroutine(TriggerSlide());
        }
    }

    private void HandleTouchAndMouseSwipe()
    {
        // Mouse / Touch down
        if (Input.GetMouseButtonDown(0))
        {
            touchStartPos = Input.mousePosition;
            isTouching = true;
        }
        else if (Input.GetMouseButtonUp(0) && isTouching)
        {
            isTouching = false;
            Vector2 delta = (Vector2)Input.mousePosition - touchStartPos;
            if (delta.magnitude >= MIN_SWIPE_DISTANCE)
            {
                if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y))
                {
                    // Horizontal swipe
                    if (delta.x > 0) MoveRightInstant();
                    else MoveLeftInstant();
                }
                else
                {
                    // Vertical swipe
                    if (delta.y > 0 && isGrounded && !isSliding) TriggerJump();
                    else if (delta.y < 0 && isGrounded && !isSliding) StartCoroutine(TriggerSlide());
                }
            }
        }
    }

    public void MoveLeftInstant()
    {
        float targetX = Mathf.Clamp(transform.position.x - 2.5f, leftLimit, rightLimit);
        transform.position = new Vector3(targetX, transform.position.y, transform.position.z);
    }

    public void MoveRightInstant()
    {
        float targetX = Mathf.Clamp(transform.position.x + 2.5f, leftLimit, rightLimit);
        transform.position = new Vector3(targetX, transform.position.y, transform.position.z);
    }

    public void TriggerJump()
    {
        verticalVelocity = jumpForce;
        isGrounded = false;
        if (jumpAudio != null) jumpAudio.Play();
        if (animator != null) animator.SetTrigger("Jump");
    }

    public IEnumerator TriggerSlide()
    {
        isSliding = true;
        if (slideAudio != null) slideAudio.Play();
        if (animator != null) animator.SetBool("isSliding", true);

        // Lower collider
        if (capsule != null)
        {
            capsule.height = originalColliderHeight * 0.45f;
            capsule.center = new Vector3(originalColliderCenter.x, originalColliderCenter.y * 0.45f, originalColliderCenter.z);
        }
        else if (controller != null)
        {
            controller.height = originalColliderHeight * 0.45f;
            controller.center = new Vector3(originalColliderCenter.x, originalColliderCenter.y * 0.45f, originalColliderCenter.z);
        }

        // Scale transform slightly for visual crouching feedback if no animator is attached
        Vector3 initialScale = transform.localScale;
        transform.localScale = new Vector3(initialScale.x, initialScale.y * 0.5f, initialScale.z);

        yield return new WaitForSeconds(slideDuration);

        // Restore collider & visual
        if (capsule != null)
        {
            capsule.height = originalColliderHeight;
            capsule.center = originalColliderCenter;
        }
        else if (controller != null)
        {
            controller.height = originalColliderHeight;
            controller.center = originalColliderCenter;
        }
        transform.localScale = initialScale;

        if (animator != null) animator.SetBool("isSliding", false);
        isSliding = false;
    }

    private void HandleJumpPhysics()
    {
        if (!isGrounded)
        {
            verticalVelocity -= gravity * Time.deltaTime;
            Vector3 pos = transform.position;
            pos.y += verticalVelocity * Time.deltaTime;

            if (pos.y <= groundY)
            {
                pos.y = groundY;
                verticalVelocity = 0f;
                isGrounded = true;
            }
            transform.position = pos;
        }
    }

    private void AttractNearbyCoins()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, magnetRadius);
        foreach (var hit in hits)
        {
            if (hit.CompareTag("Coin") || hit.GetComponent<CollectCoin>() != null)
            {
                hit.transform.position = Vector3.MoveTowards(hit.transform.position, transform.position + Vector3.up * 0.5f, 18f * Time.deltaTime);
            }
        }
    }

    public void ActivateMagnet(float duration)
    {
        StartCoroutine(MagnetRoutine(duration));
    }

    private IEnumerator MagnetRoutine(float duration)
    {
        hasMagnet = true;
        yield return new WaitForSeconds(duration);
        hasMagnet = false;
    }

    public void ActivateSpeedBoost(float multiplier, float duration)
    {
        StartCoroutine(SpeedBoostRoutine(multiplier, duration));
    }

    private IEnumerator SpeedBoostRoutine(float multiplier, float duration)
    {
        playerSpeed = originalSpeed * multiplier;
        yield return new WaitForSeconds(duration);
        playerSpeed = originalSpeed;
    }

    public void ActivateScoreMultiplier(float multiplier, float duration)
    {
        StartCoroutine(MultiplierRoutine(multiplier, duration));
    }

    private IEnumerator MultiplierRoutine(float multiplier, float duration)
    {
        MasterLevelInfo.scoreMultiplier = multiplier;
        yield return new WaitForSeconds(duration);
        MasterLevelInfo.scoreMultiplier = 1f;
    }

    public void RevivePlayer()
    {
        isAlive = true;
        isGrounded = true;
        verticalVelocity = 0f;
        transform.position = new Vector3(0, groundY, transform.position.z + 5f);
        hasShield = true; // Temporary immunity shield on revive
        isRunning = false;
    }

    IEnumerator AddDistance()
    {
        yield return new WaitForSeconds(0.25f);
        if (isAlive)
        {
            MasterLevelInfo.distanceRun += (int)(1 * MasterLevelInfo.scoreMultiplier);
        }
        isRunning = false;
    }
}
