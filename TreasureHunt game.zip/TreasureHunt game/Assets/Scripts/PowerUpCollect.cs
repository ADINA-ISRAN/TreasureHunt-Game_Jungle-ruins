using System.Collections;
using UnityEngine;

public enum PowerUpType
{
    Shield,
    Magnet,
    SpeedBoost,
    ScoreMultiplier,
    TreasureChest
}

/// <summary>
/// PowerUpCollect: Handles power-up pickups (Shield, Coin Magnet, Speed Boost, 2x Multiplier, Treasure Chest)
/// </summary>
public class PowerUpCollect : MonoBehaviour
{
    public PowerUpType powerUpType = PowerUpType.Shield;
    public float duration = 10f;
    [SerializeField] private bool collected = false;
    [SerializeField] public AudioSource powerUpAudio;

    void Update()
    {
        if (!collected)
        {
            transform.Rotate(0, 2f, 0, Space.World);
        }
        else
        {
            transform.Translate(Vector3.up * Time.deltaTime * 5f, Space.World);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (collected) return;
        PlayerMovement player = other.GetComponent<PlayerMovement>();
        if (player == null) player = other.GetComponentInParent<PlayerMovement>();
        if (player == null) return;

        collected = true;

        if (powerUpAudio != null) powerUpAudio.Play();
        else if (SoundManager.Instance != null) SoundManager.Instance.PlayPowerUp();

        switch (powerUpType)
        {
            case PowerUpType.Shield:
                player.hasShield = true;
                break;
            case PowerUpType.Magnet:
                player.ActivateMagnet(duration);
                break;
            case PowerUpType.SpeedBoost:
                player.ActivateSpeedBoost(1.5f, duration);
                break;
            case PowerUpType.ScoreMultiplier:
                player.ActivateScoreMultiplier(2f, duration);
                break;
            case PowerUpType.TreasureChest:
                // Opens bonus treasure!
                MasterLevelInfo.coinCount += 25;
                MasterLevelInfo.gemCount += 2;
                break;
        }

        StartCoroutine(ShrinkAndDeactivate());
    }

    private IEnumerator ShrinkAndDeactivate()
    {
        Vector3 initial = transform.localScale;
        float elapsed = 0f;
        while (elapsed < 0.35f)
        {
            elapsed += Time.deltaTime;
            transform.localScale = Vector3.Lerp(initial, Vector3.zero, elapsed / 0.35f);
            yield return null;
        }
        gameObject.SetActive(false);
    }
}
