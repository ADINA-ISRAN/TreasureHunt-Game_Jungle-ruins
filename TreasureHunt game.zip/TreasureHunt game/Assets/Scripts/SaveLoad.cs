using UnityEngine;

/// <summary>
/// SaveLoad: Handles persistent player progress (Coins, Gems, Keys, Highscore Distance)
/// via Unity PlayerPrefs as specified in the game architecture.
/// </summary>
public class SaveLoad : MonoBehaviour
{
    public static int loadedCoins;
    public static int loadedGems;
    public static int loadedKeys;
    public static int loadedDistance;
    public static bool saveData;

    [SerializeField] private int internalCoin;
    [SerializeField] private int internalGem;
    [SerializeField] private int internalKey;
    [SerializeField] private int internalDistance;

    void Awake()
    {
        LoadAll();
    }

    void Start()
    {
        LoadAll();
    }

    public static void LoadAll()
    {
        loadedCoins = PlayerPrefs.GetInt("COINSAVE", 0);
        loadedGems = PlayerPrefs.GetInt("GEMSAVE", 0);
        loadedKeys = PlayerPrefs.GetInt("KEYSAVE", 0);
        loadedDistance = PlayerPrefs.GetInt("DISTANCESAVE", 0);
    }

    void Update()
    {
        internalCoin = loadedCoins + MasterLevelInfo.coinCount;
        internalGem = loadedGems + MasterLevelInfo.gemCount;
        internalKey = loadedKeys + MasterLevelInfo.keyCount;
        internalDistance = Mathf.Max(loadedDistance, MasterLevelInfo.distanceRun);

        if (saveData)
        {
            saveData = false;
            ExecuteSave();
        }
    }

    public static void ExecuteSave()
    {
        int newCoins = loadedCoins + MasterLevelInfo.coinCount;
        int newGems = loadedGems + MasterLevelInfo.gemCount;
        int newKeys = loadedKeys + MasterLevelInfo.keyCount;
        int newBest = Mathf.Max(loadedDistance, MasterLevelInfo.distanceRun);

        PlayerPrefs.SetInt("COINSAVE", newCoins);
        PlayerPrefs.SetInt("GEMSAVE", newGems);
        PlayerPrefs.SetInt("KEYSAVE", newKeys);
        PlayerPrefs.SetInt("DISTANCESAVE", newBest);
        PlayerPrefs.Save();

        loadedCoins = newCoins;
        loadedGems = newGems;
        loadedKeys = newKeys;
        loadedDistance = newBest;
    }

    public static bool TryDeductGems(int cost)
    {
        LoadAll();
        int totalGems = loadedGems + MasterLevelInfo.gemCount;
        if (totalGems >= cost)
        {
            if (MasterLevelInfo.gemCount >= cost)
            {
                MasterLevelInfo.gemCount -= cost;
            }
            else
            {
                int remaining = cost - MasterLevelInfo.gemCount;
                MasterLevelInfo.gemCount = 0;
                loadedGems -= remaining;
                PlayerPrefs.SetInt("GEMSAVE", loadedGems);
                PlayerPrefs.Save();
            }
            return true;
        }
        return false;
    }
}
