using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// SegmentGenerator: Spawns modular Jungle Ruin track segments ahead of the player
/// as described in the architecture. Handles randomization, z-position progression,
/// and cleans up old segments.
/// </summary>
public class SegmentGenerator : MonoBehaviour
{
    public GameObject[] segment;
    [SerializeField] public int zPos = 50;
    [SerializeField] public bool creatingSegment = false;
    [SerializeField] public int segmentNum;
    public Transform playerTransform;

    private List<GameObject> activeSegments = new List<GameObject>();
    private const int INITIAL_SEGMENT_COUNT = 3;

    void Start()
    {
        if (playerTransform == null)
        {
            GameObject p = GameObject.FindWithTag("Player");
            if (p != null) playerTransform = p.transform;
        }

        // If no segment prefabs are assigned in inspector, generate them via JungleWorldBuilder
        if (segment == null || segment.Length == 0)
        {
            JungleWorldBuilder builder = Object.FindAnyObjectByType<JungleWorldBuilder>();
            if (builder == null)
            {
                GameObject bObj = new GameObject("JungleWorldBuilder");
                builder = bObj.AddComponent<JungleWorldBuilder>();
            }

            GameObject segA = builder.CreateSegmentA();
            segA.SetActive(false);
            GameObject segB = builder.CreateSegmentB();
            segB.SetActive(false);
            GameObject segC = builder.CreateSegmentC();
            segC.SetActive(false);
            GameObject segD = builder.CreateSegmentD();
            segD.SetActive(false);
            GameObject segE = builder.CreateSegmentE();
            segE.SetActive(false);

            segment = new GameObject[] { segA, segB, segC, segD, segE };
        }

        // Spawn initial runway
        for (int i = 0; i < INITIAL_SEGMENT_COUNT; i++)
        {
            SpawnSegment();
        }
    }

    void Update()
    {
        if (!creatingSegment)
        {
            creatingSegment = true;
            StartCoroutine(SegmentGen());
        }

        // Clean up segments that are far behind the player
        if (playerTransform != null)
        {
            for (int i = activeSegments.Count - 1; i >= 0; i--)
            {
                if (activeSegments[i] != null && activeSegments[i].transform.position.z < playerTransform.position.z - 60f)
                {
                    Destroy(activeSegments[i]);
                    activeSegments.RemoveAt(i);
                }
            }
        }
    }

    IEnumerator SegmentGen()
    {
        if (segment != null && segment.Length > 0)
        {
            SpawnSegment();
        }

        yield return new WaitForSeconds(2.8f);
        creatingSegment = false;
    }

    private void SpawnSegment()
    {
        if (segment == null || segment.Length == 0) return;

        segmentNum = Random.Range(0, segment.Length);
        GameObject newSeg = Instantiate(segment[segmentNum], new Vector3(0, 0, zPos), Quaternion.identity);
        newSeg.SetActive(true);
        activeSegments.Add(newSeg);
        zPos += 50;
    }
}
