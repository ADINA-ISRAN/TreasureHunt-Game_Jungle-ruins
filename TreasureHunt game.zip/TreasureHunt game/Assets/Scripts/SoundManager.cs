using System.Collections;
using UnityEngine;

/// <summary>
/// SoundManager: Central audio controller for SFX and background music.
/// Supports both referenced AudioClip files and procedural audio synthesis
/// to guarantee audio plays flawlessly in all conditions.
/// </summary>
public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance { get; private set; }

    [Header("Audio Clips")]
    public AudioClip coinClip;
    public AudioClip gemClip;
    public AudioClip keyClip;
    public AudioClip collisionClip;
    public AudioClip jumpClip;
    public AudioClip slideClip;
    public AudioClip buttonClickClip;
    public AudioClip powerUpClip;
    public AudioClip bgmMusicClip;

    [Header("Audio Sources")]
    private AudioSource sfxSource;
    private AudioSource musicSource;

    [Header("Volume Settings")]
    [Range(0f, 1f)] public float masterVolume = 1f;
    [Range(0f, 1f)] public float sfxVolume = 1f;
    [Range(0f, 1f)] public float musicVolume = 0.6f;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeAudioSources();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void InitializeAudioSources()
    {
        sfxSource = gameObject.AddComponent<AudioSource>();
        musicSource = gameObject.AddComponent<AudioSource>();

        musicSource.loop = true;
        musicSource.volume = musicVolume * masterVolume;

        // Try auto-loading clips from Resources or disk if not assigned
        if (bgmMusicClip != null)
        {
            musicSource.clip = bgmMusicClip;
            musicSource.Play();
        }
    }

    public void PlayCoin()
    {
        PlayClipOrSynthesize(coinClip, () => CreateToneClip(1100f, 0.15f));
    }

    public void PlayGem()
    {
        PlayClipOrSynthesize(gemClip, () => CreateChimeClip(1400f, 0.25f));
    }

    public void PlayKey()
    {
        PlayClipOrSynthesize(keyClip, () => CreateFanfareClip());
    }

    public void PlayCollision()
    {
        PlayClipOrSynthesize(collisionClip, () => CreateThudClip());
    }

    public void PlayJump()
    {
        PlayClipOrSynthesize(jumpClip, () => CreateWhooshClip(200f, 600f, 0.2f));
    }

    public void PlaySlide()
    {
        PlayClipOrSynthesize(slideClip, () => CreateWhooshClip(400f, 120f, 0.25f));
    }

    public void PlayButtonClick()
    {
        PlayClipOrSynthesize(buttonClickClip, () => CreateToneClip(800f, 0.08f));
    }

    public void PlayPowerUp()
    {
        PlayClipOrSynthesize(powerUpClip, () => CreateFanfareClip());
    }

    private void PlayClipOrSynthesize(AudioClip clip, System.Func<AudioClip> synthFunc)
    {
        if (sfxSource == null) return;
        AudioClip target = clip;
        if (target == null && synthFunc != null)
        {
            target = synthFunc.Invoke();
        }
        if (target != null)
        {
            sfxSource.PlayOneShot(target, sfxVolume * masterVolume);
        }
    }

    // Procedural Fallback Sound Synthesizers
    private AudioClip CreateToneClip(float frequency, float duration)
    {
        int sampleRate = 22050;
        int sampleCount = (int)(sampleRate * duration);
        float[] samples = new float[sampleCount];
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            samples[i] = Mathf.Sin(2f * Mathf.PI * frequency * t) * Mathf.Exp(-12f * t);
        }
        AudioClip c = AudioClip.Create("SynthTone", sampleCount, 1, sampleRate, false);
        c.SetData(samples, 0);
        return c;
    }

    private AudioClip CreateChimeClip(float baseFreq, float duration)
    {
        int sampleRate = 22050;
        int sampleCount = (int)(sampleRate * duration);
        float[] samples = new float[sampleCount];
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            float freq = baseFreq + 500f * (t / duration);
            samples[i] = Mathf.Sin(2f * Mathf.PI * freq * t) * Mathf.Exp(-8f * t);
        }
        AudioClip c = AudioClip.Create("SynthChime", sampleCount, 1, sampleRate, false);
        c.SetData(samples, 0);
        return c;
    }

    private AudioClip CreateThudClip()
    {
        int sampleRate = 22050;
        int sampleCount = (int)(sampleRate * 0.4f);
        float[] samples = new float[sampleCount];
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            float noise = Random.Range(-0.5f, 0.5f);
            samples[i] = (Mathf.Sin(2f * Mathf.PI * 70f * t) * 0.5f + noise) * Mathf.Exp(-10f * t);
        }
        AudioClip c = AudioClip.Create("SynthThud", sampleCount, 1, sampleRate, false);
        c.SetData(samples, 0);
        return c;
    }

    private AudioClip CreateWhooshClip(float startFreq, float endFreq, float duration)
    {
        int sampleRate = 22050;
        int sampleCount = (int)(sampleRate * duration);
        float[] samples = new float[sampleCount];
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            float freq = Mathf.Lerp(startFreq, endFreq, t / duration);
            samples[i] = Mathf.Sin(2f * Mathf.PI * freq * t) * Mathf.Sin(Mathf.PI * (t / duration));
        }
        AudioClip c = AudioClip.Create("SynthWhoosh", sampleCount, 1, sampleRate, false);
        c.SetData(samples, 0);
        return c;
    }

    private AudioClip CreateFanfareClip()
    {
        int sampleRate = 22050;
        int sampleCount = (int)(sampleRate * 0.5f);
        float[] samples = new float[sampleCount];
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            float freq = 523.25f + 400f * Mathf.Pow(t / 0.5f, 2f);
            samples[i] = Mathf.Sin(2f * Mathf.PI * freq * t) * Mathf.Exp(-3f * t);
        }
        AudioClip c = AudioClip.Create("SynthFanfare", sampleCount, 1, sampleRate, false);
        c.SetData(samples, 0);
        return c;
    }
}
