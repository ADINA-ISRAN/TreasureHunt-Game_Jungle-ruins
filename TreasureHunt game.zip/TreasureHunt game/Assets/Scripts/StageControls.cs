using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// StageControls: Controls the Stage Select scene where the player selects a world
/// (Jungle Ruins, Desert Temple, Lost Cave, Pirate Cove) and presses PLAY.
/// </summary>
public class StageControls : MonoBehaviour
{
    public static string selectedStage = "Jungle Ruins";

    [Header("UI & Previews")]
    [SerializeField] public GameObject[] stageCards;
    [SerializeField] public Text stageTitleText;
    [SerializeField] public AudioSource buttonAudio;
    [SerializeField] public GameObject fadeOut;

    private int currentStageIndex = 0;
    private readonly string[] stageNames = new string[] {
        "Jungle Ruins",
        "Desert Temple",
        "Lost Cave",
        "Pirate Cove"
    };

    void Start()
    {
        Button playBtn = GameObject.Find("PlayBtn")?.GetComponent<Button>();
        if (playBtn != null)
        {
            playBtn.onClick.RemoveAllListeners();
            playBtn.onClick.AddListener(PressPlay);
        }
        UpdateStageUI();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
        {
            PressPlay();
        }
    }

    public void NextStage()
    {
        currentStageIndex = (currentStageIndex + 1) % stageNames.Length;
        UpdateStageUI();
    }

    public void PreviousStage()
    {
        currentStageIndex = (currentStageIndex - 1 + stageNames.Length) % stageNames.Length;
        UpdateStageUI();
    }

    public void SelectStage(int index)
    {
        if (index >= 0 && index < stageNames.Length)
        {
            currentStageIndex = index;
            UpdateStageUI();
        }
    }

    private void UpdateStageUI()
    {
        selectedStage = stageNames[currentStageIndex];
        if (stageTitleText != null)
        {
            stageTitleText.text = selectedStage.ToUpper();
        }

        if (stageCards != null)
        {
            for (int i = 0; i < stageCards.Length; i++)
            {
                if (stageCards[i] != null)
                {
                    stageCards[i].SetActive(i == currentStageIndex);
                }
            }
        }
    }

    public void PressPlay()
    {
        StartCoroutine(PlayRoutine());
    }

    IEnumerator PlayRoutine()
    {
        if (buttonAudio != null) buttonAudio.Play();
        else if (SoundManager.Instance != null) SoundManager.Instance.PlayButtonClick();

        if (fadeOut != null) fadeOut.SetActive(true);
        yield return new WaitForSeconds(0.6f);

        // Load Information scene (Build Index 2 or name "Information")
        if (Application.CanStreamedLevelBeLoaded("Information"))
        {
            SceneManager.LoadScene("Information");
        }
        else if (SceneManager.sceneCountInBuildSettings > 2)
        {
            SceneManager.LoadScene(2);
        }
        else
        {
            SceneManager.LoadScene(1);
        }
    }
}
